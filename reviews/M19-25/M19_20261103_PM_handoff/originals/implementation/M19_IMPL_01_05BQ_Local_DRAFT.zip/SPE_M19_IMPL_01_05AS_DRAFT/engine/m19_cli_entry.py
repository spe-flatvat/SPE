"""Development-only CLI: manifest-pinned single-path legacy run.

A CLI-supplied SHA is a reproducibility pin, NOT Owner authorization.
This is not a security boundary against Python callers or modified code.
"""
import argparse
import json
import sys
from pathlib import Path
from .m19_slice_a import RunContext, SliceAStore
from .m19_execution_api import execute_year
from .m19_m10_adapter import advance_one_year
from .m19_pinned_entry import load_pinned_contract
from .m19_gate_preflight import GatePreflightError, preflight
from .m19_slice_a import digest, ConflictError
from .m19_worker_lease import ensure_lease_table, acquire, release
from .m19_fenced_recovery import fenced_recover_pending, fenced_reconcile_finalized


def execute(*, db_path, manifest_dir, manifest_sha256, year, attempt_id):
    if not isinstance(attempt_id, str) or not attempt_id.strip():
        raise GatePreflightError('CLI_INVALID_ATTEMPT_ID')
    root = Path(manifest_dir)
    manifest = load_pinned_contract(root / 'manifest.json', manifest_sha256)
    if not isinstance(manifest, dict) or not isinstance(manifest.get('context'), dict):
        raise GatePreflightError('MANIFEST_INVALID_SCHEMA')
    # All context comes from the pinned manifest, never untrusted CLI overrides.
    ctx = RunContext(**manifest['context'])
    ctx.validate()
    if type(year) is not int or year < 2026 or year > 2055:
        raise GatePreflightError('CLI_UNSUPPORTED_YEAR')
    if year == 2026:
        # Initial state is supplied only by the pinned initial contract.
        init_entry = manifest.get('initial')
        if not isinstance(init_entry, dict) or set(init_entry) != {'filename', 'sha256'}:
            raise GatePreflightError('MANIFEST_INVALID_ENTRY')
        from .m19_manifest_entry import _safe_child
        init = load_pinned_contract(_safe_child(root, init_entry['filename']), init_entry['sha256'])
        initial_state = init.get('state') if isinstance(init, dict) else None
        annual_inputs = None
        calculator = None
    else:
        from .m19_manifest_entry import _safe_child
        entry = manifest.get('numerical')
        if not isinstance(entry, dict) or set(entry) != {'filename', 'sha256'}:
            raise GatePreflightError('MANIFEST_INVALID_ENTRY')
        numerical = load_pinned_contract(_safe_child(root, entry['filename']), entry['sha256'])
        annual_inputs = numerical.get('annual_inputs', {}).get(str(year)) if isinstance(numerical, dict) else None
        initial_state = None
        calculator = advance_one_year
    # 05W: validate all pinned contracts, context, numerical bindings and
    # year-specific Gate A/C/B evidence before recovery/reconciliation mutation.
    from .m19_manifest_entry import _safe_child
    if set(manifest) != {'schema_version', 'initial', 'numerical', 'context'} or manifest['schema_version'] != 'm19-fixture-manifest-v1':
        raise GatePreflightError('MANIFEST_INVALID_SCHEMA')
    entries = []
    for name in ('initial', 'numerical'):
        entry = manifest[name]
        if not isinstance(entry, dict) or set(entry) != {'filename', 'sha256'}:
            raise GatePreflightError('MANIFEST_INVALID_ENTRY')
        entries.append(_safe_child(root, entry['filename']))
    if entries[0] == entries[1] or any(e.name == 'manifest.json' for e in entries):
        raise GatePreflightError('MANIFEST_COLLIDING_FILES')
    initial_contract = load_pinned_contract(entries[0], manifest['initial']['sha256'])
    numerical_contract = load_pinned_contract(entries[1], manifest['numerical']['sha256'])
    if numerical_contract.get('contract_id') != ctx.input_contract_ref or numerical_contract.get('policy_ref') != ctx.effective_policy_ref:
        raise GatePreflightError('C_NUMERICAL_CONTRACT_CONTEXT_MISMATCH')
    coverage = numerical_contract.get('covered_years')
    if not isinstance(coverage, list) or year not in coverage or any(type(y) is not int for y in coverage):
        raise GatePreflightError('C_YEAR_NOT_COVERED')
    if year == 2026:
        if initial_contract.get('contract_id') != ctx.initial_contract_ref or initial_contract.get('approval_id') != ctx.initial_approval_ref:
            raise GatePreflightError('A_INITIAL_CONTRACT_CONTEXT_MISMATCH')
        if initial_contract.get('state_digest') != digest(initial_state) or numerical_contract.get('initial_state_digest') != digest(initial_state):
            raise GatePreflightError('A_INITIAL_STATE_DIGEST_MISMATCH')
        preflight(year=year, initial_state=initial_state, initial_contract=initial_contract,
                  numerical_contract=numerical_contract, transition_requested=False)
    else:
        expected = numerical_contract.get('annual_input_digests')
        if not isinstance(expected, dict) or expected.get(str(year)) != digest(annual_inputs):
            raise GatePreflightError('C_ANNUAL_INPUT_DIGEST_MISMATCH')
    # The remaining prior-year evidence check needs a read-only DB lookup.
    # No attempt or recovery status is changed before this check.
    store = SliceAStore(str(db_path))
    lease = None
    try:
        # Prior-year evidence must be read before creating a lease row.
        # This is a read-only preflight; acquiring a lease is a DB mutation.
        if year > 2026:
            prior = store.read(ctx, year-1)
            if prior is None:
                raise GatePreflightError('A_PREVIOUS_FINALIZATION_EVIDENCE_MISSING')
        ensure_lease_table(store.db)
        owner_id = 'cli:' + attempt_id
        lease = acquire(store.db, ctx, year, owner_id)
        if year > 2026:
            prior = store.read(ctx, year-1)
            if prior is None:
                raise GatePreflightError('A_PREVIOUS_FINALIZATION_EVIDENCE_MISSING')
            state, result_hash, _, _ = prior
            event = store.db.execute("SELECT event_type,result_digest FROM year_end WHERE execution_id=? AND path_id=? AND year=?",
                                     (ctx.execution_id,ctx.path_id,year-1)).fetchone()
            if event != ('SUCCESS',result_hash):
                raise ConflictError('Previous finalization event mismatch')
            preflight(year=year, previous_state=state, previous_finalization={
                'year':year-1,'status':'SUCCESS','result_digest':result_hash,
                'event_ref':'fixture-year-end:'+ctx.execution_id+':'+ctx.path_id+':'+str(year-1),
                'history_ref':'fixture-annual:'+ctx.execution_id+':'+ctx.path_id+':'+str(year-1)},
                annual_inputs=annual_inputs,numerical_contract=numerical_contract,transition_requested=False)
        # Recovery and reconciliation require the same current lease as finalization.
        # A finalized year may have interrupted, nonwinning attempts.
        if store.read(ctx, year) is None:
            recovered = fenced_recover_pending(store, ctx, year, owner_id, lease)
        else:
            recovered = 0
        # Execute using the same verified in-memory contract snapshots used by
        # preflight. Never reopen mutable contract paths after acquiring a lease.
        result = execute_year(store, ctx, year,
            initial_contract=initial_contract, numerical_contract=numerical_contract,
            initial_state=initial_state, annual_inputs=annual_inputs,
            calculator=calculator, attempt_id=attempt_id,
            transition_requested=False, fence=(owner_id, lease))
        reconciled = fenced_reconcile_finalized(store, ctx, year, owner_id, lease)
        return {'year': year, 'result_digest': result[1], 'created': result[2],
                'recovered_attempts': recovered, 'reconciled_attempts': reconciled}
    finally:
        # Always close the SQLite connection, even when lease release fails.
        # Do not allow a release error to mask an in-flight execution error.
        active_error = sys.exc_info()[0] is not None
        try:
            if lease is not None:
                try:
                    release(store.db, ctx, year, owner_id, lease)
                except Exception:
                    if not active_error:
                        raise
        finally:
            store.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description='Development-only pinned manifest entry; NOT production-authorized')
    parser.add_argument('--db', required=True)
    parser.add_argument('--manifest-dir', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--year', type=int, required=True)
    parser.add_argument('--attempt-id', required=True)
    args = parser.parse_args(argv)
    try:
        print(json.dumps(execute(db_path=args.db, manifest_dir=args.manifest_dir,
            manifest_sha256=args.manifest_sha256, year=args.year,
            attempt_id=args.attempt_id), sort_keys=True))
        return 0
    except Exception as exc:
        print(f'STOP: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 2

if __name__ == '__main__':
    sys.exit(main())
