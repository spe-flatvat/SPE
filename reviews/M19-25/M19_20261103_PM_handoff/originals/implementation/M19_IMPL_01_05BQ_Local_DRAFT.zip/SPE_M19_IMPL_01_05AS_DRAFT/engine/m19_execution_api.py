"""05AV experimental two-layer API (DRAFT; no production authorization).

The supported normal entry delegates to the fenced strict implementation.
Legacy fixture APIs intentionally remain available in their original modules;
Python callers can still import them. This is an interface separation,
not a sandbox or a security boundary against modified code.
"""
from .m19_strict_entry import run_year_strict


def execute_year(store, ctx, year, *, fence, **kwargs):
    """Normal library entry: requires an explicit current worker fence."""
    return run_year_strict(store, ctx, year, fence=fence, **kwargs)
