"""Development-only fenced recovery/reconciliation for a single year.

Lease fencing and attempt updates share one BEGIN IMMEDIATE transaction.
The existing unfenced SliceAStore methods remain available for fixtures.
"""
from .m19_slice_a import ConflictError, ContractError
from .m19_worker_lease import assert_fence_in_transaction


def _validate(ctx, year, reason):
    ctx.validate()
    if type(year) is not int or year < 2026:
        raise ContractError('Invalid recovery year')
    if not isinstance(reason, str) or not reason.strip():
        raise ContractError('Recovery reason required')


def fenced_recover_pending(store, ctx, year, owner_id, generation, *, reason='RECOVERED_AFTER_INTERRUPTION'):
    _validate(ctx, year, reason)
    db = store.db
    try:
        db.execute('BEGIN IMMEDIATE')
        assert_fence_in_transaction(db, ctx, year, owner_id, generation)
        finalized = store.read(ctx, year)
        pending = db.execute('''SELECT COUNT(*) FROM attempts WHERE execution_id=? AND path_id=?
            AND year=? AND status='PENDING' ''', (ctx.execution_id, ctx.path_id, year)).fetchone()[0]
        if finalized is not None:
            if pending:
                raise ConflictError('Pending attempts coexist with finalized result')
            db.commit()
            return 0
        cur = db.execute('''UPDATE attempts SET status='FAILED', reason=?
            WHERE execution_id=? AND path_id=? AND year=? AND status='PENDING' ''',
            (reason, ctx.execution_id, ctx.path_id, year))
        db.commit()
        return cur.rowcount
    except BaseException:
        db.rollback()
        raise


def fenced_reconcile_finalized(store, ctx, year, owner_id, generation, *, reason='SUPERSEDED_BY_FINALIZED_YEAR'):
    _validate(ctx, year, reason)
    db = store.db
    try:
        db.execute('BEGIN IMMEDIATE')
        assert_fence_in_transaction(db, ctx, year, owner_id, generation)
        if store.read(ctx, year) is None:
            raise ConflictError('No finalized year to reconcile against')
        winning = db.execute('''SELECT attempt_id FROM annual WHERE execution_id=?
            AND path_id=? AND year=?''', (ctx.execution_id, ctx.path_id, year)).fetchone()[0]
        status = db.execute('SELECT status FROM attempts WHERE attempt_id=?', (winning,)).fetchone()
        if status != ('SUCCEEDED',):
            raise ConflictError('Finalized attempt status is inconsistent')
        cur = db.execute('''UPDATE attempts SET status='FAILED', reason=?
            WHERE execution_id=? AND path_id=? AND year=? AND status='PENDING' AND attempt_id<>?''',
            (reason, ctx.execution_id, ctx.path_id, year, winning))
        db.commit()
        return cur.rowcount
    except BaseException:
        db.rollback()
        raise
