"""Explicit fixture-only compatibility exports. NOT a production entry.

Importing these names bypasses the normal strict entry and invalidates any
claim that the result was produced through the normal fenced execution API.
This module does not authenticate callers or enforce use restrictions.
"""
from .m19_slice_a import SliceAStore, run_year
from .m19_guarded_runner import run_year_bound, run_year_guarded

__all__ = ('SliceAStore', 'run_year', 'run_year_bound', 'run_year_guarded')
