"""Development-only, explicit-evidence Gate preflight; no normative approval claim.

This helper deliberately does not modify SliceAStore or issue policy authorization.
Inputs are fixtures, not trusted attestations. Missing or contradictory evidence fails closed.
"""
from dataclasses import dataclass
from math import isfinite
from typing import Mapping

class GatePreflightError(ValueError):
    pass

REQUIRED_STATE = frozenset({'year','real_gdp','nominal_gdp','tax_revenue',
                             'expenditure','population','deaths','births'})
REQUIRED_INPUTS = frozenset({'risk_shock','aging_drag','tax_elasticity','expenditure_growth'})

@dataclass(frozen=True)
class GateRecord:
    gate: str
    outcome: str
    reason: str


def _ref(value):
    return isinstance(value,str) and bool(value.strip())


def check_state(state: Mapping, year: int):
    if not isinstance(state,Mapping) or set(state)!=REQUIRED_STATE or type(state.get('year')) is not int or state['year']!=year:
        raise GatePreflightError('STATE_SCHEMA_OR_YEAR_INVALID')
    for name in REQUIRED_STATE-{'year'}:
        value=state[name]
        if type(value) not in (int,float) or not isfinite(value) or value < 0:
            raise GatePreflightError('STATE_NUMERIC_INVALID:'+name)


def preflight(*, year:int, initial_state=None, previous_state=None,
              initial_contract=None, previous_finalization=None,
              annual_inputs=None, numerical_contract=None,
              transition_requested=False):
    """Only legacy single-path no-switch development fixtures are supported.

    A: evidence for initial contract or finalized prior-year state.
    C: explicit numerical contract and inputs; 2026 has no transition inputs.
    B: NOT_APPLICABLE only if no transition is requested; otherwise STOP.
    """
    if type(year) is not int or not 2026 <= year <= 2055:
        raise GatePreflightError('YEAR_OUT_OF_LEGACY_SCOPE')
    records=[]
    if year==2026:
        check_state(initial_state,2026)
        if not isinstance(initial_contract,Mapping) or initial_contract.get('baseline_year')!=2026 or not all(_ref(initial_contract.get(k)) for k in ('contract_id','approval_id','provenance_ref','units_ref')):
            raise GatePreflightError('A_INITIAL_CONTRACT_EVIDENCE_MISSING')
        if initial_contract.get('state')!=initial_state:
            raise GatePreflightError('A_INITIAL_CONTRACT_STATE_MISMATCH')
        if previous_state is not None or previous_finalization is not None:
            raise GatePreflightError('A_2026_MUST_NOT_INHERIT_2025')
    else:
        check_state(previous_state,year-1)
        if not isinstance(previous_finalization,Mapping) or previous_finalization.get('year')!=year-1 or previous_finalization.get('status')!='SUCCESS' or not all(_ref(previous_finalization.get(k)) for k in ('result_digest','event_ref','history_ref')):
            raise GatePreflightError('A_PREVIOUS_FINALIZATION_EVIDENCE_MISSING')
        if initial_state is not None:
            raise GatePreflightError('A_UNEXPECTED_INITIAL_STATE')
    records.append(GateRecord('A','PASS','Development evidence shape checked; not approval authenticated'))
    if year==2026:
        if annual_inputs is not None:
            raise GatePreflightError('C_INITIAL_YEAR_INPUTS_FORBIDDEN')
    else:
        if not isinstance(annual_inputs,Mapping) or set(annual_inputs)!=REQUIRED_INPUTS:
            raise GatePreflightError('C_REQUIRED_INPUTS_MISSING')
        for k,v in annual_inputs.items():
            if type(v) not in (int,float) or not isfinite(v):
                raise GatePreflightError('C_INPUT_INVALID:'+k)
        if annual_inputs['expenditure_growth'] < -1:
            raise GatePreflightError('C_EXPENDITURE_GROWTH_INVALID')
    if not isinstance(numerical_contract,Mapping) or not all(_ref(numerical_contract.get(k)) for k in ('contract_id','units_ref','provenance_ref','coverage_ref','policy_effects_ref')):
        raise GatePreflightError('C_NUMERICAL_CONTRACT_EVIDENCE_MISSING')
    records.append(GateRecord('C','PASS','Development numeric fixture checked; no Owner approval authenticated'))
    if type(transition_requested) is not bool:
        raise GatePreflightError('B_TRANSITION_FLAG_INVALID')
    if transition_requested:
        raise GatePreflightError('B_DEPENDENT_TRANSITION_UNSUPPORTED')
    records.append(GateRecord('B','NOT_APPLICABLE','Legacy incumbent continuation; no dependent transition'))
    return tuple(records)
