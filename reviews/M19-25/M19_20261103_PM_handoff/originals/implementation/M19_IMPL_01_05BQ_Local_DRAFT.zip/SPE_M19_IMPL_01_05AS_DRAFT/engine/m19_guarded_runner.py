"""Development-only, fail-closed preflight wrapper for legacy Slice A.

This wrapper is opt-in; direct run_year remains an unguarded fixture entry.
No approval or source attestation is authenticated by this module.
"""
from .m19_slice_a import ContractError, ConflictError, run_year, digest
from .m19_gate_preflight import preflight, GatePreflightError


def run_year_guarded(store, ctx, year, *, initial_state=None, annual_inputs=None,
                     calculator=None, attempt_id, initial_contract=None,
                     numerical_contract=None, transition_requested=False,
                     fail_before_commit=False, fence=None):
    ctx.validate()
    # Fixture-only reference binding. A nonempty reference is not authentication.
    if not isinstance(numerical_contract, dict) or numerical_contract.get('contract_id') != ctx.input_contract_ref:
        raise GatePreflightError('C_NUMERICAL_CONTRACT_CONTEXT_MISMATCH')
    if year == 2026:
        if (not isinstance(initial_contract, dict)
            or initial_contract.get('contract_id') != ctx.initial_contract_ref
            or initial_contract.get('approval_id') != ctx.initial_approval_ref):
            raise GatePreflightError('A_INITIAL_CONTRACT_CONTEXT_MISMATCH')
    if year == 2026:
        preflight(year=year, initial_state=initial_state,
                  initial_contract=initial_contract,
                  numerical_contract=numerical_contract,
                  annual_inputs=annual_inputs,
                  transition_requested=transition_requested)
    else:
        prior = store.read(ctx, year - 1)
        if prior is None:
            raise GatePreflightError('A_PREVIOUS_FINALIZATION_EVIDENCE_MISSING')
        state, result_hash, contract_ref, _ = prior
        # Derive evidence from the same store, never from caller-supplied strings.
        event = store.db.execute('''SELECT event_type,result_digest FROM year_end
            WHERE execution_id=? AND path_id=? AND year=?''',
            (ctx.execution_id, ctx.path_id, year-1)).fetchone()
        if event != ('SUCCESS', result_hash):
            raise ConflictError('Previous finalization event mismatch')
        preflight(year=year, previous_state=state,
                  previous_finalization={'year':year-1, 'status':'SUCCESS',
                      'result_digest':result_hash,
                      'event_ref':f'fixture-year-end:{ctx.execution_id}:{ctx.path_id}:{year-1}',
                      'history_ref':f'fixture-annual:{ctx.execution_id}:{ctx.path_id}:{year-1}'},
                  annual_inputs=annual_inputs, numerical_contract=numerical_contract,
                  transition_requested=transition_requested)
    return run_year(store, ctx, year, initial_state=initial_state,
                    annual_inputs=annual_inputs, calculator=calculator,
                    attempt_id=attempt_id, fail_before_commit=fail_before_commit, fence=fence)


def run_year_bound(store, ctx, year, *, initial_state=None, annual_inputs=None,
                   calculator=None, attempt_id, initial_contract=None,
                   numerical_contract=None, transition_requested=False,
                   fail_before_commit=False, fence=None):
    """Strict development fixture: bind actual values to contract digests.

    Does not authenticate Owner approvals and does not replace direct run_year.
    """
    if not isinstance(numerical_contract, dict):
        raise GatePreflightError('C_NUMERICAL_CONTRACT_MISSING')
    if numerical_contract.get('policy_ref') != ctx.effective_policy_ref:
        raise GatePreflightError('C_POLICY_CONTEXT_MISMATCH')
    coverage = numerical_contract.get('covered_years')
    if not isinstance(coverage, list) or year not in coverage or any(type(y) is not int for y in coverage):
        raise GatePreflightError('C_YEAR_NOT_COVERED')
    if year == 2026:
        if not isinstance(initial_contract, dict) or initial_contract.get('state_digest') != digest(initial_state):
            raise GatePreflightError('A_INITIAL_STATE_DIGEST_MISMATCH')
        if numerical_contract.get('initial_state_digest') != digest(initial_state):
            raise GatePreflightError('C_INITIAL_STATE_DIGEST_MISMATCH')
    else:
        if not isinstance(annual_inputs, dict):
            raise GatePreflightError('C_ANNUAL_INPUTS_MISSING')
        expected = numerical_contract.get('annual_input_digests')
        if not isinstance(expected, dict) or expected.get(str(year)) != digest(annual_inputs):
            raise GatePreflightError('C_ANNUAL_INPUT_DIGEST_MISMATCH')
    return run_year_guarded(store, ctx, year, initial_state=initial_state,
        annual_inputs=annual_inputs, calculator=calculator, attempt_id=attempt_id,
        initial_contract=initial_contract, numerical_contract=numerical_contract,
        transition_requested=transition_requested, fail_before_commit=fail_before_commit, fence=fence)
