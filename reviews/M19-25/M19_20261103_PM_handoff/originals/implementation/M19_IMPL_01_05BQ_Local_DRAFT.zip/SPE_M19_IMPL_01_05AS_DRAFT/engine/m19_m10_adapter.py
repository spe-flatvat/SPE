"""Development-only, independent one-year port of M10 advance() at fixed main.

NOT a source-extracted function. Numerical parity with the entire M10 CLI
is not established by this module; review and regression are mandatory.
"""
from math import isfinite

FIELDS = ('year','real_gdp','nominal_gdp','tax_revenue','expenditure','population','deaths','births')
PARAMS = ('risk_shock','aging_drag','tax_elasticity','expenditure_growth')


def advance_one_year(previous, inputs, *, real_wage_growth_rate=0.0):
    if set(previous) != set(FIELDS) or type(previous['year']) is not int:
        raise ValueError('Invalid previous state fields')
    if set(inputs) != set(PARAMS):
        raise ValueError('Invalid annual input keys')
    if any(type(previous[k]) not in (float,int) or not isfinite(previous[k]) for k in FIELDS if k!='year'):
        raise ValueError('Invalid previous numeric state')
    if any(type(v) not in (float,int) or not isfinite(v) for v in inputs.values()):
        raise ValueError('Invalid annual inputs')
    if type(real_wage_growth_rate) not in (int,float) or not isfinite(real_wage_growth_rate):
        raise ValueError('Invalid wage growth')
    if previous['population'] <= 0 or inputs['expenditure_growth'] < -1:
        raise ValueError('Invalid population or expenditure growth')
    deaths = previous['deaths'] * 1.015
    births = previous['births'] * 0.975 * (1 + 0.15 * real_wage_growth_rate)
    population = previous['population'] + births - deaths
    population_growth = population / previous['population'] - 1
    labor_force_growth = population_growth + inputs['aging_drag']
    real_growth = 0.01 - inputs['risk_shock'] + (1 - 0.35) * labor_force_growth
    nominal_growth = real_growth + 0.02
    real_gdp = previous['real_gdp'] * (1 + real_growth)
    nominal_gdp = previous['nominal_gdp'] * (1 + nominal_growth)
    tax_before_cap = previous['tax_revenue'] * (1 + nominal_growth * inputs['tax_elasticity'])
    tax_revenue = min(tax_before_cap, nominal_gdp * 0.30)
    expenditure = previous['expenditure'] * (1 + inputs['expenditure_growth'])
    result = dict(year=previous['year']+1, real_gdp=real_gdp,
                  nominal_gdp=nominal_gdp, tax_revenue=tax_revenue,
                  expenditure=expenditure, population=population,
                  deaths=deaths, births=births)
    if not all(isfinite(v) for v in result.values()):
        raise ValueError('Non-finite result')
    return result


def annual_to_m10_result(states, *, scenario='fixture', profile='fixture'):
    """Build a development-only m10.1-shaped result; not formal M12 validation."""
    return {'schema_version':'m10.1','scenario':scenario,'profile':profile,
            'years':{str(year):{**state,'bonds':max(state['expenditure']-state['tax_revenue'],0)}
                     for year,state in sorted(states.items())}}
