"""Development-only M18-equivalent evaluation; NOT original M18 source execution.

Based on fixed GitHub m18_evaluate.py at 13c24ae8...; M12-like strict
validation is local and does not establish SA-09 original-source parity.
"""
from math import isclose, isfinite

FIELDS = {'year','real_gdp','nominal_gdp','tax_revenue','expenditure','population','deaths','births','bonds'}

def validate_m10_fixture(data):
    if not isinstance(data, dict) or data.get('schema_version') != 'm10.1':
        raise ValueError('Unsupported result schema')
    years = data.get('years')
    if not isinstance(years, dict) or not years:
        raise ValueError('Invalid years')
    for key, state in years.items():
        if not isinstance(key, str) or len(key) != 4 or not key.isascii() or not key.isdecimal():
            raise ValueError('Invalid year key')
        if not isinstance(state, dict) or set(state) != FIELDS or type(state['year']) is not int or state['year'] != int(key):
            raise ValueError('Invalid state')
        for field in FIELDS - {'year'}:
            val = state[field]
            if type(val) not in (int, float) or not isfinite(val) or val < 0:
                raise ValueError('Invalid numeric value')
        if not isclose(state['bonds'], max(state['expenditure']-state['tax_revenue'],0), rel_tol=1e-10, abs_tol=1e-9):
            raise ValueError('Bond mismatch')
    ordered = sorted(map(int,years))
    if ordered != list(range(ordered[0],ordered[-1]+1)):
        raise ValueError('Noncontiguous years')
    return years

def evaluate_m18_fixture(data):
    years = validate_m10_fixture(data)
    ordered = sorted(map(int,years))
    start, end = ordered[0],ordered[-1]
    if start != 2026 or end <= start:
        raise ValueError('Invalid evaluation window')
    first,last = years[str(start)],years[str(end)]
    if first['real_gdp'] <= 0:
        raise ValueError('Initial real GDP must be positive')
    ratios=[]
    for year in ordered:
        state=years[str(year)]
        if state['nominal_gdp'] <= 0:
            raise ValueError('Nominal GDP must be positive')
        ratios.append(state['tax_revenue']/state['nominal_gdp'])
    return dict(start_year=start,end_year=end,is_2055_endpoint=end==2055,
                real_gdp_endpoint=last['real_gdp'],
                real_gdp_cagr=(last['real_gdp']/first['real_gdp'])**(1/(end-start))-1,
                real_median_wage_endpoint=last.get('real_median_wage'),
                gini_coefficient_endpoint=last.get('gini_coefficient'),
                population_endpoint=last['population'],tax_to_gdp_ratio_max=max(ratios),
                bond_issuance_endpoint=last['bonds'])
