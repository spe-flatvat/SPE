"""Development-only manifest-pinned entry; external digest is NOT Owner authorization.

The caller must obtain manifest_sha256 from a separate trusted channel.
This entry cannot make direct fixture functions inaccessible to Python callers.
"""
from pathlib import Path
from .m19_pinned_entry import load_pinned_contract, run_year_pinned
from .m19_gate_preflight import GatePreflightError


def _safe_child(root, name):
    if not isinstance(name, str) or not name or name in ('.', '..'):
        raise GatePreflightError('MANIFEST_INVALID_FILENAME')
    p = Path(name)
    if p.is_absolute() or len(p.parts) != 1 or p.name != name or "\\" in name:
        raise GatePreflightError('MANIFEST_INVALID_FILENAME')
    return root / name


def run_year_manifest(store, ctx, year, *, manifest_dir, manifest_sha256,
                      initial_state=None, annual_inputs=None, calculator=None,
                      attempt_id, transition_requested=False, fail_before_commit=False, fence=None):
    root = Path(manifest_dir)
    if root.is_symlink() or not root.is_dir():
        raise GatePreflightError('MANIFEST_UNSAFE_DIRECTORY')
    manifest = load_pinned_contract(root/'manifest.json', manifest_sha256)
    if set(manifest) != {'schema_version','initial','numerical','context'} or manifest['schema_version'] != 'm19-fixture-manifest-v1':
        raise GatePreflightError('MANIFEST_INVALID_SCHEMA')
    expected_context = {key:getattr(ctx,key) for key in (
        'execution_id','path_id','effective_policy_ref','initial_contract_ref',
        'initial_approval_ref','input_contract_ref','start_year','mode')}
    if manifest['context'] != expected_context:
        raise GatePreflightError('MANIFEST_CONTEXT_MISMATCH')
    paths=[]
    for key in ('initial','numerical'):
        entry=manifest[key]
        if not isinstance(entry,dict) or set(entry) != {'filename','sha256'}:
            raise GatePreflightError('MANIFEST_INVALID_ENTRY')
        paths.append(_safe_child(root,entry['filename']))
    if paths[0] == paths[1] or paths[0].name == 'manifest.json' or paths[1].name == 'manifest.json':
        raise GatePreflightError('MANIFEST_COLLIDING_FILES')
    return run_year_pinned(store,ctx,year,
        initial_contract_path=paths[0],initial_contract_sha256=manifest['initial']['sha256'],
        numerical_contract_path=paths[1],numerical_contract_sha256=manifest['numerical']['sha256'],
        initial_state=initial_state,annual_inputs=annual_inputs,calculator=calculator,
        attempt_id=attempt_id,transition_requested=transition_requested,
        fail_before_commit=fail_before_commit, fence=fence)
