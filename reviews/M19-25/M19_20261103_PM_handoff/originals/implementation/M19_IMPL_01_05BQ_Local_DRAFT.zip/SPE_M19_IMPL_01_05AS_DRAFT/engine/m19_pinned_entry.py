"""Development-only pinned-file entry. Digest pins must come from a separately trusted channel.

No Owner authorization is established by this module. Direct fixture APIs remain accessible.
"""
import hashlib
import json
from pathlib import Path
from .m19_guarded_runner import run_year_bound
from .m19_gate_preflight import GatePreflightError


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise GatePreflightError('PIN_DUPLICATE_JSON_KEY')
        result[key] = value
    return result


def load_pinned_contract(path, expected_sha256):
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64 or any(c not in '0123456789abcdef' for c in expected_sha256):
        raise GatePreflightError('PIN_INVALID_DIGEST')
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise GatePreflightError('PIN_UNSAFE_PATH')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise GatePreflightError('PIN_CONTENT_MISMATCH')
    try:
        def invalid_constant(value):
            raise ValueError('Non-finite JSON constant: '+value)
        obj = json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_pairs,
                         parse_constant=invalid_constant)
    except GatePreflightError:
        raise
    except (ValueError, UnicodeError) as exc:
        raise GatePreflightError('PIN_INVALID_JSON') from exc
    if not isinstance(obj, dict):
        raise GatePreflightError('PIN_NON_OBJECT')
    return obj


def run_year_pinned(store, ctx, year, *, initial_contract_path, initial_contract_sha256,
                    numerical_contract_path, numerical_contract_sha256,
                    initial_state=None, annual_inputs=None, calculator=None, attempt_id,
                    transition_requested=False, fail_before_commit=False, fence=None):
    """Resolve both pinned contracts before any annual calculation or attempt write."""
    initial_contract = load_pinned_contract(initial_contract_path, initial_contract_sha256)
    numerical_contract = load_pinned_contract(numerical_contract_path, numerical_contract_sha256)
    return run_year_bound(store, ctx, year, initial_state=initial_state,
        annual_inputs=annual_inputs, calculator=calculator, attempt_id=attempt_id,
        initial_contract=initial_contract, numerical_contract=numerical_contract,
        transition_requested=transition_requested, fail_before_commit=fail_before_commit, fence=fence)
