"""M19 Slice A development-only controller; no production authorization.

Legacy 2026 single path, no transitions. The numerical calculator is injected;
this module does not import side-effectful m10_results.py.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import sqlite3
from typing import Callable, Mapping


class ContractError(ValueError):
    pass


class ConflictError(RuntimeError):
    pass


def digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class RunContext:
    execution_id: str
    path_id: str
    effective_policy_ref: str
    initial_contract_ref: str
    initial_approval_ref: str
    input_contract_ref: str
    start_year: int = 2026
    mode: str = "legacy"

    def validate(self) -> None:
        if self.mode != "legacy" or self.start_year != 2026:
            raise ContractError("Only legacy 2026 is supported")
        for name in ("execution_id", "path_id", "effective_policy_ref",
                     "initial_contract_ref", "initial_approval_ref", "input_contract_ref"):
            if not isinstance(getattr(self, name), str) or not getattr(self, name).strip():
                raise ContractError(f"Missing {name}")


class SliceAStore:
    """SQLite atomic result/year-end store, append-only attempts and gates."""

    def __init__(self, path: str):
        self.db = sqlite3.connect(path)
        try:
            self.db.execute("PRAGMA foreign_keys=ON")
            self.db.executescript("""
        CREATE TABLE IF NOT EXISTS attempts (
            attempt_id TEXT PRIMARY KEY, execution_id TEXT NOT NULL,
            path_id TEXT NOT NULL, year INTEGER NOT NULL, contract_ref TEXT NOT NULL,
            status TEXT NOT NULL, result_digest TEXT, reason TEXT
        );
        CREATE TABLE IF NOT EXISTS gates (
            id INTEGER PRIMARY KEY AUTOINCREMENT, execution_id TEXT NOT NULL,
            path_id TEXT NOT NULL, year INTEGER NOT NULL, gate TEXT NOT NULL,
            outcome TEXT NOT NULL, reason TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS annual (
            execution_id TEXT NOT NULL, path_id TEXT NOT NULL, year INTEGER NOT NULL,
            contract_ref TEXT NOT NULL, previous_digest TEXT,
            result_digest TEXT NOT NULL, result_json TEXT NOT NULL,
            attempt_id TEXT NOT NULL,
            PRIMARY KEY(execution_id, path_id, year),
            FOREIGN KEY(attempt_id) REFERENCES attempts(attempt_id)
        );
        CREATE TABLE IF NOT EXISTS year_end (
            execution_id TEXT NOT NULL, path_id TEXT NOT NULL, year INTEGER NOT NULL,
            result_digest TEXT NOT NULL, event_type TEXT NOT NULL,
            PRIMARY KEY(execution_id, path_id, year),
            FOREIGN KEY(execution_id,path_id,year) REFERENCES annual(execution_id,path_id,year)
        );
        """)
        except BaseException:
            self.db.close()
            raise

    def close(self):
        self.db.close()

    def read(self, ctx: RunContext, year: int):
        row = self.db.execute("""SELECT result_json,result_digest,contract_ref,previous_digest
            FROM annual WHERE execution_id=? AND path_id=? AND year=?""",
            (ctx.execution_id, ctx.path_id, year)).fetchone()
        if not row:
            return None
        state = json.loads(row[0])
        if digest(state) != row[1]:
            raise ConflictError("Stored annual state digest mismatch")
        event = self.db.execute("""SELECT result_digest,event_type FROM year_end
            WHERE execution_id=? AND path_id=? AND year=?""",
            (ctx.execution_id, ctx.path_id, year)).fetchone()
        if event != (row[1], "SUCCESS"):
            raise ConflictError("Annual state lacks matching successful year-end")
        return state, row[1], row[2], row[3]

    def _fenced_write(self, ctx, year, fence, sql, params):
        """Validate the current lease in the very transaction that writes a gate/attempt."""
        if fence is None:
            self.db.execute(sql, params)
            self.db.commit()
            return
        from .m19_worker_lease import assert_fence_in_transaction
        try:
            self.db.execute("BEGIN IMMEDIATE")
            assert_fence_in_transaction(self.db, ctx, year, *fence)
            self.db.execute(sql, params)
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise

    def gate(self, ctx: RunContext, year: int, name: str, outcome: str, reason: str, *, fence=None):
        self._fenced_write(ctx, year, fence,
            "INSERT INTO gates(execution_id,path_id,year,gate,outcome,reason) VALUES(?,?,?,?,?,?)",
            (ctx.execution_id,ctx.path_id,year,name,outcome,reason))

    def attempt(self, ctx: RunContext, year: int, attempt_id: str, status: str,
                result_digest: str | None, reason: str | None, *, fence=None):
        if fence is None:
            if self.db.execute("SELECT 1 FROM attempts WHERE attempt_id=?", (attempt_id,)).fetchone():
                raise ConflictError("Attempt identity already exists")
        self._fenced_write(ctx, year, fence,
            "INSERT INTO attempts VALUES(?,?,?,?,?,?,?,?)",
            (attempt_id,ctx.execution_id,ctx.path_id,year,
             ctx.input_contract_ref,status,result_digest,reason))

    def recover_pending(self, ctx: RunContext, year: int, *, reason="RECOVERED_AFTER_INTERRUPTION"):
        """Fixture-only recovery. Mark orphan PENDING attempts FAILED, never fabricate results.

        Caller must ensure exclusive ownership of this execution/path/year.
        Recovery is not a production authorization or lease protocol.
        """
        ctx.validate()
        if not reason or not reason.strip():
            raise ContractError("Recovery reason required")
        try:
            self.db.execute("BEGIN IMMEDIATE")
            if self.read(ctx, year) is not None:
                # A finalized year must not have pending attempts; flag inconsistency.
                pending = self.db.execute("""SELECT COUNT(*) FROM attempts
                    WHERE execution_id=? AND path_id=? AND year=? AND status='PENDING'""",
                    (ctx.execution_id, ctx.path_id, year)).fetchone()[0]
                if pending:
                    raise ConflictError("Pending attempts coexist with finalized result")
                self.db.commit()
                return 0
            cur = self.db.execute("""UPDATE attempts SET status='FAILED', reason=?
                WHERE execution_id=? AND path_id=? AND year=? AND status='PENDING'""",
                (reason, ctx.execution_id, ctx.path_id, year))
            count = cur.rowcount
            self.db.commit()
            return count
        except BaseException:
            self.db.rollback()
            raise

    def reconcile_after_finalization(self, ctx: RunContext, year: int, *,
                                     reason="SUPERSEDED_BY_FINALIZED_YEAR") -> int:
        """Fixture-only, exclusive-owner reconciliation of losing PENDING attempts.

        Never changes the winning attempt or the finalized annual/year-end data.
        Not safe against a concurrently running worker without external exclusion.
        """
        ctx.validate()
        if type(year) is not int or year < 2026:
            raise ContractError("Invalid reconciliation year")
        if not isinstance(reason, str) or not reason.strip():
            raise ContractError("Reconciliation reason required")
        try:
            self.db.execute("BEGIN IMMEDIATE")
            finalized = self.read(ctx, year)
            if finalized is None:
                raise ConflictError("No finalized year to reconcile against")
            winning = self.db.execute("""SELECT attempt_id FROM annual
                WHERE execution_id=? AND path_id=? AND year=?""",
                (ctx.execution_id, ctx.path_id, year)).fetchone()[0]
            winner_status = self.db.execute("SELECT status FROM attempts WHERE attempt_id=?",
                                            (winning,)).fetchone()
            if winner_status != ("SUCCEEDED",):
                raise ConflictError("Finalized attempt status is inconsistent")
            cur = self.db.execute("""UPDATE attempts SET status='FAILED', reason=?
                WHERE execution_id=? AND path_id=? AND year=?
                  AND status='PENDING' AND attempt_id<>?""",
                (reason, ctx.execution_id, ctx.path_id, year, winning))
            count = cur.rowcount
            self.db.commit()
            return count
        except BaseException:
            self.db.rollback()
            raise

    def finalize(self, ctx: RunContext, year: int, result: dict,
                 attempt_id: str, previous_digest: str | None, *, fail_before_commit=False,
                 fence: tuple | None = None):
        result_hash = digest(result)
        try:
            self.db.execute("BEGIN IMMEDIATE")
            if fence is not None:
                from .m19_worker_lease import assert_fence_in_transaction
                assert_fence_in_transaction(self.db, ctx, year, *fence)
            owner = self.db.execute("""SELECT execution_id,path_id,year,contract_ref,status
                FROM attempts WHERE attempt_id=?""", (attempt_id,)).fetchone()
            if owner != (ctx.execution_id,ctx.path_id,year,ctx.input_contract_ref,"PENDING"):
                raise ConflictError("Attempt ownership, contract, or status mismatch")
            old = self.read(ctx, year)
            if old:
                if old[1] != result_hash or old[2] != ctx.input_contract_ref or old[3] != previous_digest:
                    raise ConflictError("Competing finalization")
                self.db.commit()
                return old[0], old[1], False
            self.db.execute("""INSERT INTO annual VALUES(?,?,?,?,?,?,?,?)""",
                            (ctx.execution_id,ctx.path_id,year,ctx.input_contract_ref,
                             previous_digest,result_hash,json.dumps(result,sort_keys=True),attempt_id))
            if fail_before_commit:
                raise RuntimeError("Injected crash before year-end")
            self.db.execute("UPDATE attempts SET status='SUCCEEDED', result_digest=? WHERE attempt_id=? AND status='PENDING'", (result_hash, attempt_id))
            if self.db.execute("SELECT changes()").fetchone()[0] != 1:
                raise ConflictError("Attempt not pending")
            self.db.execute("INSERT INTO year_end VALUES(?,?,?,?,?)",
                            (ctx.execution_id,ctx.path_id,year,result_hash,"SUCCESS"))
            self.db.commit()
            return result,result_hash,True
        except BaseException:
            self.db.rollback()
            raise


def run_year(store: SliceAStore, ctx: RunContext, year: int, *,
             initial_state: Mapping[str, object] | None,
             annual_inputs: Mapping[str, object] | None,
             calculator: Callable[[dict, dict], dict] | None,
             attempt_id: str, fail_before_commit=False, fence=None):
    """Development fixture entry. Caller supplies validated numeric contracts.

    This does NOT attest to Owner approval of initial/annual contracts.
    """
    ctx.validate()
    if type(year) is not int or year < 2026:
        raise ContractError("Year precedes legacy initial state")
    if not isinstance(attempt_id,str) or not attempt_id.strip():
        raise ContractError("Missing attempt identity")
    prior = None
    if year == 2026:
        if not isinstance(initial_state, Mapping) or initial_state.get("year") != 2026:
            store.gate(ctx,year,"A","FAIL","Initial state contract fixture missing", fence=fence)
            raise ContractError("Initial state missing or wrong year")
        state = dict(initial_state)
        previous_digest = None
    else:
        prior = store.read(ctx,year-1)
        if prior is None:
            store.gate(ctx,year,"A","FAIL","Previous finalized numeric state missing", fence=fence)
            raise ContractError("Previous finalized year required")
        state, previous_digest = prior[0], prior[1]
    store.gate(ctx,year,"A","PASS","Fixture state reference checked", fence=fence)
    if year > 2026 and (not isinstance(annual_inputs, Mapping) or not annual_inputs):
        store.gate(ctx,year,"C","FAIL","Annual numeric fixture missing", fence=fence)
        raise ContractError("Annual input missing")
    if year == 2026 and annual_inputs is not None:
        store.gate(ctx,year,"C","FAIL","Initial year must not carry annual transition inputs", fence=fence)
        raise ContractError("Unexpected initial-year annual inputs")
    store.gate(ctx,year,"C","PASS","Fixture contract presence checked; not production validation", fence=fence)
    store.gate(ctx,year,"B","NOT_APPLICABLE","Single path, no policy transition fixture", fence=fence)
    if year == 2026:
        result = state
    else:
        if calculator is None:
            raise ContractError("No annual numerical calculator")
        try:
            result = calculator(state, dict(annual_inputs))
            if not isinstance(result,dict) or result.get("year") != year:
                raise ContractError("Calculator returned invalid year")
        except Exception as exc:
            store.attempt(ctx,year,attempt_id,"FAILED",None,type(exc).__name__, fence=fence)
            raise
    if not isinstance(result,dict):
        raise ContractError("Calculator returned non-object state")
    if result.get("year") != year:
        raise ContractError("Result year mismatch")
    result_hash = digest(result)
    existing = store.read(ctx, year)
    if existing is not None:
        if existing[1] != result_hash or existing[2] != ctx.input_contract_ref or existing[3] != previous_digest:
            raise ConflictError("Competing finalization")
        if fence is not None:
            # Even idempotent success must not be acknowledged by a stale owner.
            from .m19_worker_lease import assert_fence_in_transaction
            try:
                store.db.execute('BEGIN IMMEDIATE')
                assert_fence_in_transaction(store.db, ctx, year, *fence)
                store.db.commit()
            except BaseException:
                store.db.rollback()
                raise
        return existing[0], existing[1], False
    store.attempt(ctx,year,attempt_id,"PENDING",None,None, fence=fence)
    return store.finalize(ctx,year,result,attempt_id,previous_digest,
                          fail_before_commit=fail_before_commit, fence=fence)
