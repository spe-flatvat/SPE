"""Opt-in strict fixture entry. Does not authenticate Owner approvals.

Direct legacy fixture APIs remain accessible and are NOT production boundaries.
"""
from .m19_slice_a import ContractError
from .m19_guarded_runner import run_year_bound
from .m19_worker_lease import assert_fence_in_transaction


def run_year_strict(store, ctx, year, *, fence, **kwargs):
    """Reject missing/stale fencing before any gate/attempt mutation.

    Ownership is rechecked by each fenced mutation and finalization.
    """
    ctx.validate()
    if (not isinstance(fence, tuple) or len(fence) != 2
            or not isinstance(fence[0], str) or not fence[0].strip()
            or type(fence[1]) is not int or fence[1] < 1):
        raise ContractError('STRICT_FENCE_REQUIRED')
    try:
        store.db.execute('BEGIN IMMEDIATE')
        assert_fence_in_transaction(store.db, ctx, year, *fence)
        store.db.commit()
    except BaseException:
        store.db.rollback()
        raise
    return run_year_bound(store, ctx, year, fence=fence, **kwargs)
