"""Development-only SQLite fencing lease for a single annual worker.

All lease operations use BEGIN IMMEDIATE. Fencing validation MUST be performed
in the same transaction as annual finalization; standalone check is insufficient.
"""
import sqlite3
import time
from .m19_slice_a import ConflictError, ContractError


def ensure_lease_table(db):
    db.execute('''CREATE TABLE IF NOT EXISTS worker_leases (
      execution_id TEXT NOT NULL, path_id TEXT NOT NULL, year INTEGER NOT NULL,
      owner_id TEXT NOT NULL, generation INTEGER NOT NULL, expires_at REAL NOT NULL,
      PRIMARY KEY(execution_id,path_id,year))''')
    db.commit()


def acquire(db, ctx, year, owner_id, ttl=30.0, now=None):
    if not isinstance(owner_id,str) or not owner_id.strip() or type(year) is not int or year < 2026:
        raise ContractError('Invalid lease identity')
    if type(ttl) not in (int,float) or not 0 < ttl <= 3600:
        raise ContractError('Invalid lease TTL')
    now = time.time() if now is None else now
    try:
        db.execute('BEGIN IMMEDIATE')
        key = (ctx.execution_id,ctx.path_id,year)
        row = db.execute('SELECT owner_id,generation,expires_at FROM worker_leases WHERE execution_id=? AND path_id=? AND year=?',key).fetchone()
        if row and row[2] > now:
            raise ConflictError('Annual lease currently owned; no early takeover')
        generation = row[1]+1 if row else 1
        if row:
            db.execute('UPDATE worker_leases SET owner_id=?,generation=?,expires_at=? WHERE execution_id=? AND path_id=? AND year=?',(owner_id,generation,now+ttl,*key))
        else:
            db.execute('INSERT INTO worker_leases VALUES(?,?,?,?,?,?)',(*key,owner_id,generation,now+ttl))
        db.commit()
        return generation
    except BaseException:
        db.rollback()
        raise


def assert_fence_in_transaction(db,ctx,year,owner_id,generation,now=None):
    now = time.time() if now is None else now
    row=db.execute('SELECT owner_id,generation,expires_at FROM worker_leases WHERE execution_id=? AND path_id=? AND year=?',(ctx.execution_id,ctx.path_id,year)).fetchone()
    if not row or row[0]!=owner_id or row[1]!=generation or row[2]<=now:
        raise ConflictError('STALE_WORKER_FENCE')


def release(db,ctx,year,owner_id,generation):
    try:
        db.execute('BEGIN IMMEDIATE')
        assert_fence_in_transaction(db,ctx,year,owner_id,generation)
        db.execute('UPDATE worker_leases SET expires_at=0 WHERE execution_id=? AND path_id=? AND year=?',(ctx.execution_id,ctx.path_id,year))
        db.commit()
    except BaseException:
        db.rollback()
        raise
