import hashlib
import json
import subprocess
import sys
from pathlib import Path
import unittest
from tests.test_gate_preflight import INITIAL, NUM
from engine.m19_slice_a import RunContext, SliceAStore, digest
from tests.test_gate_preflight import STATE, INPUT

class CliFixtureMixin:
    def setUp(self):
        import tempfile
        self.tmp=tempfile.TemporaryDirectory()
        self.base=Path(self.tmp.name)
        self.store=SliceAStore(str(self.base/'store.db'))
        self.ctx=RunContext('pin-exec','pin-path','policy-fixture','fixture-ic','fixture-only-not-real','fixture-nc')
        self.ic={**INITIAL,'state_digest':digest(STATE)}
        self.nc={**NUM,'policy_ref':'policy-fixture','covered_years':[2026,2027],
                 'initial_state_digest':digest(STATE),'annual_input_digests':{'2027':digest(INPUT)}}
        self.ip,self.ih=self.write('initial.json',self.ic)
        self.np,self.nh=self.write('numerical.json',self.nc)
        self.manifest={'schema_version':'m19-fixture-manifest-v1',
            'initial':{'filename':self.ip.name,'sha256':self.ih},
            'numerical':{'filename':self.np.name,'sha256':self.nh},
            'context':{key:getattr(self.ctx,key) for key in
                ('execution_id','path_id','effective_policy_ref','initial_contract_ref',
                 'initial_approval_ref','input_contract_ref','start_year','mode')}}
        self.ic['state'] = STATE
        self.nc['annual_inputs'] = {'2027': INPUT}
        self.ip,self.ih=self.write('initial.json',self.ic)
        self.np,self.nh=self.write('numerical.json',self.nc)
        self.manifest['initial']['sha256']=self.ih
        self.manifest['numerical']['sha256']=self.nh
        self.repin()
        self.db=self.base/'cli.db'
    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()
    def write(self,name,obj):
        p=self.base/name
        raw=json.dumps(obj,sort_keys=True).encode()
        p.write_bytes(raw)
        return p,hashlib.sha256(raw).hexdigest()
    def repin(self):
        raw=json.dumps(self.manifest,sort_keys=True).encode()
        (self.base/'manifest.json').write_bytes(raw)
        self.pin=hashlib.sha256(raw).hexdigest()
    def cli(self,year=2026,pin=None,attempt=None):
        args=[sys.executable,'-m','engine.m19_cli_entry','--db',str(self.db),
              '--manifest-dir',str(self.base),'--manifest-sha256',pin or self.pin,
              '--year',str(year),'--attempt-id',attempt or f'cli-{year}']
        return subprocess.run(args,cwd=str(Path(__file__).resolve().parents[1]),capture_output=True,text=True,timeout=20)
