import tempfile
import unittest
from pathlib import Path
from engine.m19_guarded_runner import run_year_bound
from engine.m19_gate_preflight import GatePreflightError
from engine.m19_slice_a import RunContext, SliceAStore, digest
from engine.m19_m10_adapter import advance_one_year
from tests.test_gate_preflight import STATE, INITIAL, NUM, INPUT

class BoundRunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=SliceAStore(str(Path(self.temp.name)/'bound.db'))
        self.ctx=RunContext('exec-fixture','path-fixture','policy-fixture','fixture-ic','fixture-only-not-real','fixture-nc')
        self.ic={**INITIAL,'state_digest':digest(STATE)}
        self.nc={**NUM,'policy_ref':'policy-fixture','covered_years':[2026,2027],
                 'initial_state_digest':digest(STATE),
                 'annual_input_digests':{'2027':digest(INPUT)}}
    def tearDown(self):
        self.store.close();self.temp.cleanup()
    def run26(self,**overrides):
        args=dict(initial_state=STATE,initial_contract=self.ic,numerical_contract=self.nc,attempt_id='a26')
        args.update(overrides)
        return run_year_bound(self.store,self.ctx,2026,**args)
    def run27(self,**overrides):
        args=dict(annual_inputs=INPUT,initial_contract=self.ic,numerical_contract=self.nc,
                  calculator=advance_one_year,attempt_id='a27')
        args.update(overrides)
        return run_year_bound(self.store,self.ctx,2027,**args)
    def assert_empty(self):
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],0)
    def test_bound_two_year_execution(self):
        self.assertTrue(self.run26()[2]);self.assertTrue(self.run27()[2])
        self.assertEqual(self.store.read(self.ctx,2027)[0]['year'],2027)
    def test_initial_state_tampering_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'A_INITIAL_STATE_DIGEST'):
            self.run26(initial_state={**STATE,'tax_revenue':81.0})
        self.assert_empty()
    def test_initial_contract_digest_tampering_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'A_INITIAL_STATE_DIGEST'):
            self.run26(initial_contract={**self.ic,'state_digest':'fake'})
        self.assert_empty()
    def test_numerical_initial_digest_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'C_INITIAL_STATE_DIGEST'):
            self.run26(numerical_contract={**self.nc,'initial_state_digest':'fake'})
        self.assert_empty()
    def test_policy_context_mismatch_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'C_POLICY_CONTEXT'):
            self.run26(numerical_contract={**self.nc,'policy_ref':'other'})
        self.assert_empty()
    def test_year_coverage_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'C_YEAR_NOT_COVERED'):
            self.run26(numerical_contract={**self.nc,'covered_years':[2027]})
        self.assert_empty()
    def test_annual_input_tampering_rejected(self):
        self.run26()
        with self.assertRaisesRegex(GatePreflightError,'C_ANNUAL_INPUT_DIGEST'):
            self.run27(annual_inputs={**INPUT,'risk_shock':0.10})
        self.assertIsNone(self.store.read(self.ctx,2027))
    def test_missing_year_input_digest_rejected(self):
        self.run26()
        with self.assertRaisesRegex(GatePreflightError,'C_ANNUAL_INPUT_DIGEST'):
            self.run27(numerical_contract={**self.nc,'annual_input_digests':{}})
        self.assertIsNone(self.store.read(self.ctx,2027))
    def test_unsupported_transition_still_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'B_DEPENDENT_TRANSITION'):
            self.run26(transition_requested=True)
        self.assert_empty()

if __name__=='__main__': unittest.main()
