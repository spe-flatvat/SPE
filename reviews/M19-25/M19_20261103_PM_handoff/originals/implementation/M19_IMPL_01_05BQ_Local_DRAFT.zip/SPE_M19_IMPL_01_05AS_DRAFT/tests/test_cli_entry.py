import json
import unittest
from tests.cli_fixture import CliFixtureMixin

class CliEntryTests(CliFixtureMixin, unittest.TestCase):
    def test_cli_two_years(self):
        a=self.cli(); self.assertEqual(a.returncode,0,a.stderr)
        b=self.cli(2027);self.assertEqual(b.returncode,0,b.stderr)
        self.assertTrue(json.loads(a.stdout)['created']);self.assertTrue(json.loads(b.stdout)['created'])
    def test_cli_wrong_manifest_pin(self):
        r=self.cli(pin='0'*64);self.assertEqual(r.returncode,2)
        self.assertFalse(self.db.exists())
    def test_cli_missing_initial_value(self):
        self.ic.pop('state',None);self.ip,self.ih=self.write('initial.json',self.ic)
        self.manifest['initial']['sha256']=self.ih;self.repin()
        self.assertEqual(self.cli().returncode,2)
    def test_cli_reject_unsupported_year(self):
        self.assertEqual(self.cli(2056).returncode,2)
        self.assertFalse(self.db.exists())
    def test_cli_detects_mutated_contract(self):
        self.np.write_text('{}')
        self.assertEqual(self.cli().returncode,2)
    def test_cli_no_implicit_transition(self):
        self.assertEqual(self.cli(2027).returncode,2) # prior year absent
