import json
import sqlite3
import unittest
import unittest
from tests.cli_fixture import CliFixtureMixin
from engine.m19_worker_lease import acquire, ensure_lease_table
from engine.m19_slice_a import SliceAStore, ConflictError

class CliFencedTests(CliFixtureMixin, unittest.TestCase):
    def test_cli_releases_lease_after_success(self):
        r=self.cli()
        self.assertEqual(r.returncode,0,r.stderr)
        db=sqlite3.connect(self.db)
        row=db.execute('SELECT generation,expires_at FROM worker_leases WHERE year=2026').fetchone()
        self.assertEqual(row[0],1)
        self.assertEqual(row[1],0)
        db.close()

    def test_cli_rejects_live_competitor(self):
        db=SliceAStore(str(self.db))
        ensure_lease_table(db.db)
        acquire(db.db,self.ctx,2026,'competing-owner')
        db.close()
        r=self.cli()
        self.assertEqual(r.returncode,2)
        self.assertIn('lease currently owned',r.stderr)
        db=SliceAStore(str(self.db))
        self.assertIsNone(db.read(self.ctx,2026))
        db.close()

    def test_cli_failure_releases_lease(self):
        self.ic.pop('state',None)
        self.ip,self.ih=self.write('initial.json',self.ic)
        self.manifest['initial']['sha256']=self.ih
        self.repin()
        r=self.cli()
        self.assertEqual(r.returncode,2)
        db=sqlite3.connect(self.db)
        # Contract failure occurs before lease acquisition (05W+).
        self.assertIsNone(db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='worker_leases'").fetchone())
        db.close()

    def test_cli_reacquire_increments_generation(self):
        a=self.cli()
        self.assertEqual(a.returncode,0,a.stderr)
        b=self.cli(attempt='different-attempt')
        self.assertEqual(b.returncode,0,b.stderr)
        self.assertFalse(json.loads(b.stdout)['created'])
        db=sqlite3.connect(self.db)
        self.assertEqual(db.execute('SELECT generation FROM worker_leases WHERE year=2026').fetchone()[0],2)
        db.close()
