from contextlib import closing
import sqlite3
import unittest
from tests.cli_fixture import CliFixtureMixin
from engine.m19_slice_a import SliceAStore

class PreflightBeforeRecoveryTests(CliFixtureMixin, unittest.TestCase):
    def seed(self, year, attempt):
        s=SliceAStore(str(self.db))
        s.attempt(self.ctx, year, attempt, 'PENDING', None, None)
        s.close()

    def _pending(self):
        with closing(sqlite3.connect(self.db)) as db:
            return db.execute("SELECT status FROM attempts WHERE attempt_id='orphan'").fetchone()

    def test_2026_mutated_numerical_contract_does_not_recover(self):
        self.seed(2026,'orphan'); self.np.write_text('{}')
        self.assertEqual(self.cli().returncode,2)
        self.assertEqual(self._pending(),('PENDING',))

    def test_2026_missing_initial_state_does_not_recover(self):
        self.seed(2026,'orphan'); self.ic.pop('state');self.ip,self.ih=self.write('initial.json',self.ic)
        self.manifest['initial']['sha256']=self.ih;self.repin()
        self.assertEqual(self.cli().returncode,2)
        self.assertEqual(self._pending(),('PENDING',))

    def test_2026_validly_rehashed_wrong_state_does_not_recover(self):
        self.seed(2026,'orphan');self.ic['state']['real_gdp'] += 1
        self.ip,self.ih=self.write('initial.json',self.ic)
        self.manifest['initial']['sha256']=self.ih;self.repin()
        self.assertEqual(self.cli().returncode,2)
        self.assertEqual(self._pending(),('PENDING',))

    def test_2026_context_mismatch_does_not_recover(self):
        self.seed(2026,'orphan');self.manifest['context']['input_contract_ref']='other';self.repin()
        self.assertEqual(self.cli().returncode,2)
        self.assertEqual(self._pending(),('PENDING',))

    def test_2027_invalid_inputs_do_not_recover(self):
        self.assertEqual(self.cli().returncode,0)
        self.seed(2027,'orphan')
        self.nc['annual_inputs']['2027']['risk_shock'] += 1
        self.np,self.nh=self.write('numerical.json',self.nc)
        self.manifest['numerical']['sha256']=self.nh;self.repin()
        self.assertEqual(self.cli(2027).returncode,2)
        self.assertEqual(self._pending(),('PENDING',))

    def test_2027_missing_prior_year_does_not_recover(self):
        self.seed(2027,'orphan')
        self.assertEqual(self.cli(2027).returncode,2)
        self.assertEqual(self._pending(),('PENDING',))

    def test_valid_recovery_still_succeeds(self):
        self.seed(2026,'orphan')
        self.assertEqual(self.cli().returncode,0)
        self.assertEqual(self._pending(),('FAILED',))
