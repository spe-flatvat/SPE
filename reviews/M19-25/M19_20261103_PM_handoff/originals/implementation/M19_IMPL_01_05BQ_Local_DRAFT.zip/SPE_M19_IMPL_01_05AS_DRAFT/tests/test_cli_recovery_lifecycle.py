from contextlib import closing
import json
import sqlite3
import unittest
from tests.cli_fixture import CliFixtureMixin
from engine.m19_slice_a import SliceAStore

class CliRecoveryLifecycleTests(CliFixtureMixin, unittest.TestCase):
    def seed(self, year, attempt):
        s=SliceAStore(str(self.db))
        s.attempt(self.ctx, year, attempt, 'PENDING', None, None)
        s.close()

    def test_recover_orphan_before_initial_finalization(self):
        self.seed(2026, 'orphan-2026')
        r=self.cli()
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(json.loads(r.stdout)['recovered_attempts'],1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute("SELECT status FROM attempts WHERE attempt_id='orphan-2026'").fetchone(),('FAILED',))

    def test_reconcile_orphan_after_finalization(self):
        self.assertEqual(self.cli().returncode,0)
        self.seed(2026, 'orphan-after')
        r=self.cli(attempt='retry-2026')
        self.assertEqual(r.returncode,0,r.stderr)
        payload=json.loads(r.stdout)
        self.assertFalse(payload['created'])
        self.assertEqual(payload['reconciled_attempts'],1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute("SELECT status FROM attempts WHERE attempt_id='orphan-after'").fetchone(),('FAILED',))

    def test_recovery_is_idempotent_across_retries(self):
        self.seed(2026,'orphan-once')
        a=self.cli();b=self.cli(attempt='retry')
        self.assertEqual(a.returncode,0,a.stderr)
        self.assertEqual(b.returncode,0,b.stderr)
        self.assertEqual(json.loads(b.stdout)['recovered_attempts'],0)
        self.assertEqual(json.loads(b.stdout)['reconciled_attempts'],0)

    def test_competing_lease_prevents_recovery(self):
        from engine.m19_worker_lease import ensure_lease_table, acquire
        self.seed(2026,'protected-orphan')
        s=SliceAStore(str(self.db));ensure_lease_table(s.db)
        acquire(s.db,self.ctx,2026,'other-worker')
        s.close()
        r=self.cli()
        self.assertEqual(r.returncode,2)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute("SELECT status FROM attempts WHERE attempt_id='protected-orphan'").fetchone(),('PENDING',))
