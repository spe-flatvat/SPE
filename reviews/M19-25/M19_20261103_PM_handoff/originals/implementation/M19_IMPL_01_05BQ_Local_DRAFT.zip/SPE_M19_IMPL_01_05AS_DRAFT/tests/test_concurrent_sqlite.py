"""SQLite multi-connection tests, NOT a lease/worker ownership protocol."""
import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'engine'))
from m19_slice_a import SliceAStore, RunContext, run_year, ConflictError
from m19_m10_adapter import advance_one_year

CTX=RunContext('fixture-multi','F','fixture-policy','fixture-initial','fixture-approval','fixture-input')
INIT={'year':2026,'real_gdp':580.,'nominal_gdp':600.,'tax_revenue':80.,'expenditure':108.,'population':121500000,'deaths':1590000,'births':640000}
I27={'risk_shock':0.05,'aging_drag':-0.005,'tax_elasticity':1.5,'expenditure_growth':0.025}

class TestMultiConnection(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        p=str(Path(self.tmp.name)/'multi.db')
        self.a=SliceAStore(p); self.b=SliceAStore(p)
        run_year(self.a,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='initial')
    def tearDown(self):
        self.a.close(); self.b.close(); self.tmp.cleanup()
    def run27(self,store,attempt='a27',inputs=I27):
        return run_year(store,CTX,2027,initial_state=None,annual_inputs=inputs,calculator=advance_one_year,attempt_id=attempt)
    def test_second_connection_observes_finalized_result(self):
        first=self.run27(self.a)
        second=self.run27(self.b,'b27')
        self.assertTrue(first[2]); self.assertFalse(second[2]); self.assertEqual(first[:2],second[:2])
        self.assertEqual(self.b.db.execute("SELECT COUNT(*) FROM attempts WHERE year=2027").fetchone()[0],1)
    def test_conflicting_second_connection_rejected(self):
        self.run27(self.a)
        with self.assertRaises(ConflictError):
            self.run27(self.b,'bad27',{**I27,'risk_shock':0.0})
        self.assertEqual(self.a.db.execute("SELECT COUNT(*) FROM year_end WHERE year=2027").fetchone()[0],1)
    def test_reconcile_loser_visible_across_connections(self):
        self.b.attempt(CTX,2027,'loser','PENDING',None,None)
        self.run27(self.a)
        self.assertEqual(self.b.reconcile_after_finalization(CTX,2027),1)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone()[0],'FAILED')
    def test_recovery_not_allowed_when_finalized_and_pending(self):
        self.b.attempt(CTX,2027,'loser','PENDING',None,None)
        self.run27(self.a)
        with self.assertRaises(ConflictError):self.b.recover_pending(CTX,2027)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone()[0],'PENDING')

if __name__=='__main__':unittest.main()
