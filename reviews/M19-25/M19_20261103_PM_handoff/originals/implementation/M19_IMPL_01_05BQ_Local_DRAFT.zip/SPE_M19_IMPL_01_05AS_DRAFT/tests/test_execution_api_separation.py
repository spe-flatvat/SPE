import os
import tempfile
import unittest
from engine.m19_execution_api import execute_year
from engine.m19_fixture_api import SliceAStore, run_year, run_year_bound
from engine.m19_slice_a import RunContext, ContractError
from engine.m19_worker_lease import ensure_lease_table, acquire

class ExecutionApiSeparationTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix='.sqlite3')
        os.close(fd)
        self.store = SliceAStore(self.path)
        self.ctx = RunContext('execution','F','policy','initial','approval','numerical')
        ensure_lease_table(self.store.db)

    def tearDown(self):
        self.store.close()
        os.unlink(self.path)

    def counts(self):
        return tuple(self.store.db.execute('SELECT count(*) FROM '+name).fetchone()[0]
                     for name in ('gates','attempts','annual','year_end'))

    def test_missing_fence_rejected_before_mutation(self):
        for fence in (None, (), ('worker',True), ('worker',0)):
            with self.subTest(fence=fence):
                with self.assertRaises(ContractError):
                    execute_year(self.store,self.ctx,2026,fence=fence,attempt_id='a')
                self.assertEqual(self.counts(),(0,0,0,0))

    def test_stale_fence_rejected_before_mutation(self):
        generation=acquire(self.store.db,self.ctx,2026,'worker')
        with self.assertRaises(Exception):
            execute_year(self.store,self.ctx,2026,fence=('worker',generation+1),attempt_id='a')
        self.assertEqual(self.counts(),(0,0,0,0))

    def test_fixture_exports_are_explicit_not_removed(self):
        self.assertTrue(callable(run_year))
        self.assertTrue(callable(run_year_bound))

    def test_cli_uses_normal_facade(self):
        import inspect
        from engine import m19_cli_entry
        self.assertIn('execute_year(',inspect.getsource(m19_cli_entry.execute))
