import tempfile
import unittest
from pathlib import Path
from engine.m19_slice_a import SliceAStore, RunContext, ConflictError
from engine.m19_worker_lease import ensure_lease_table, acquire, release

CTX=RunContext('e','p','F','init','approval','inputs')

class FencedWriteTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.a=SliceAStore(str(Path(self.tmp.name)/'db.sqlite'))
        self.b=SliceAStore(str(Path(self.tmp.name)/'db.sqlite'))
        ensure_lease_table(self.a.db)
    def tearDown(self):
        self.a.close(); self.b.close(); self.tmp.cleanup()
    def test_stale_generation_cannot_write_gate_or_attempt(self):
        old=acquire(self.a.db,CTX,2026,'owner')
        release(self.a.db,CTX,2026,'owner',old)
        new=acquire(self.b.db,CTX,2026,'owner')
        self.assertEqual(new,old+1)
        with self.assertRaises(ConflictError):
            self.a.gate(CTX,2026,'A','PASS','stale',fence=('owner',old))
        with self.assertRaises(ConflictError):
            self.a.attempt(CTX,2026,'stale','PENDING',None,None,fence=('owner',old))
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM gates').fetchone()[0],0)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM attempts').fetchone()[0],0)
    def test_current_owner_can_write(self):
        gen=acquire(self.a.db,CTX,2026,'owner')
        self.b.gate(CTX,2026,'A','PASS','ok',fence=('owner',gen))
        self.b.attempt(CTX,2026,'ok','PENDING',None,None,fence=('owner',gen))
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM gates').fetchone()[0],1)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM attempts').fetchone()[0],1)
