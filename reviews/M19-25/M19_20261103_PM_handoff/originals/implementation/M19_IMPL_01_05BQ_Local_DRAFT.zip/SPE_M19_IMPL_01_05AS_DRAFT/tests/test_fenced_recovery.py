import tempfile
import time
import unittest
from pathlib import Path
from engine.m19_slice_a import SliceAStore, RunContext, ConflictError
from engine.m19_worker_lease import ensure_lease_table, acquire, release
from engine.m19_fenced_recovery import fenced_recover_pending, fenced_reconcile_finalized

CTX=RunContext('recovery-e','F','p','i','a','c')

class FencedRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        path=str(Path(self.tmp.name)/'test.db')
        self.a=SliceAStore(path); self.b=SliceAStore(path)
        ensure_lease_table(self.a.db)
        self.g=acquire(self.a.db,CTX,2027,'A')
    def tearDown(self):
        self.a.close();self.b.close();self.tmp.cleanup()
    def pending(self, name):
        self.a.attempt(CTX,2027,name,'PENDING',None,None)
    def test_fenced_recovery_marks_pending(self):
        self.pending('old')
        self.assertEqual(fenced_recover_pending(self.a,CTX,2027,'A',self.g),1)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='old'").fetchone(),('FAILED',))
    def test_fenced_recovery_idempotent(self):
        self.pending('old')
        self.assertEqual(fenced_recover_pending(self.a,CTX,2027,'A',self.g),1)
        self.assertEqual(fenced_recover_pending(self.a,CTX,2027,'A',self.g),0)
    def test_stale_owner_cannot_recover(self):
        self.pending('old')
        release(self.a.db,CTX,2027,'A',self.g)
        acquire(self.b.db,CTX,2027,'B')
        with self.assertRaises(ConflictError): fenced_recover_pending(self.a,CTX,2027,'A',self.g)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='old'").fetchone(),('PENDING',))
    def test_same_owner_old_generation_rejected(self):
        self.pending('old')
        release(self.a.db,CTX,2027,'A',self.g)
        new=acquire(self.b.db,CTX,2027,'A')
        self.assertGreater(new,self.g)
        with self.assertRaises(ConflictError): fenced_recover_pending(self.a,CTX,2027,'A',self.g)
    def test_fenced_reconciliation(self):
        self.pending('winner')
        self.a.finalize(CTX,2027,{'year':2027},'winner',None,fence=('A',self.g))
        self.pending('loser')
        self.assertEqual(fenced_reconcile_finalized(self.a,CTX,2027,'A',self.g),1)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='winner'").fetchone(),('SUCCEEDED',))
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone(),('FAILED',))
    def test_stale_owner_cannot_reconcile(self):
        self.pending('winner')
        self.a.finalize(CTX,2027,{'year':2027},'winner',None,fence=('A',self.g))
        self.pending('loser')
        release(self.a.db,CTX,2027,'A',self.g)
        acquire(self.b.db,CTX,2027,'B')
        with self.assertRaises(ConflictError): fenced_reconcile_finalized(self.a,CTX,2027,'A',self.g)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone(),('PENDING',))
    def test_no_finalized_reconciliation_rejected(self):
        self.pending('orphan')
        with self.assertRaises(ConflictError): fenced_reconcile_finalized(self.a,CTX,2027,'A',self.g)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='orphan'").fetchone(),('PENDING',))

if __name__=='__main__': unittest.main()
