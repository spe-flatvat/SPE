import unittest
from engine.m19_gate_preflight import preflight, GatePreflightError

STATE=dict(year=2026,real_gdp=580.0,nominal_gdp=600.0,tax_revenue=80.0,
           expenditure=108.0,population=121500000,deaths=1590000,births=640000)
INITIAL=dict(baseline_year=2026,contract_id='fixture-ic',approval_id='fixture-only-not-real',
             provenance_ref='fixture-source',units_ref='fixture-units',state=STATE)
NUM=dict(contract_id='fixture-nc',units_ref='fixture-units',provenance_ref='fixture-source',
         coverage_ref='fixture-coverage',policy_effects_ref='fixture-policy-effects')
INPUT=dict(risk_shock=.05,aging_drag=-.005,tax_elasticity=1.5,expenditure_growth=.025)
PREV=dict(year=2026,status='SUCCESS',result_digest='fixture-digest',event_ref='fixture-event',history_ref='fixture-history')

class GatePreflightTests(unittest.TestCase):
    def test_2026_pass_no_gate_b_authorization(self):
        result=preflight(year=2026,initial_state=STATE,initial_contract=INITIAL,numerical_contract=NUM)
        self.assertEqual([(x.gate,x.outcome) for x in result],[('A','PASS'),('C','PASS'),('B','NOT_APPLICABLE')])
    def test_2027_pass(self):
        result=preflight(year=2027,previous_state=STATE,previous_finalization=PREV,annual_inputs=INPUT,numerical_contract=NUM)
        self.assertEqual(result[-1].outcome,'NOT_APPLICABLE')
    def test_no_approval_reference_fails(self):
        with self.assertRaisesRegex(GatePreflightError,'A_INITIAL_CONTRACT'):
            preflight(year=2026,initial_state=STATE,initial_contract={**INITIAL,'approval_id':''},numerical_contract=NUM)
    def test_initial_state_mismatch_fails(self):
        with self.assertRaisesRegex(GatePreflightError,'A_INITIAL_CONTRACT_STATE_MISMATCH'):
            preflight(year=2026,initial_state=STATE,initial_contract={**INITIAL,'state':{**STATE,'real_gdp':999}},numerical_contract=NUM)
    def test_2025_inheritance_forbidden(self):
        with self.assertRaisesRegex(GatePreflightError,'A_2026_MUST_NOT_INHERIT_2025'):
            preflight(year=2026,initial_state=STATE,initial_contract=INITIAL,numerical_contract=NUM,previous_state=STATE)
    def test_missing_prior_finalization_fails(self):
        with self.assertRaisesRegex(GatePreflightError,'A_PREVIOUS_FINALIZATION'):
            preflight(year=2027,previous_state=STATE,annual_inputs=INPUT,numerical_contract=NUM)
    def test_missing_numerical_provenance_fails(self):
        with self.assertRaisesRegex(GatePreflightError,'C_NUMERICAL_CONTRACT'):
            preflight(year=2027,previous_state=STATE,previous_finalization=PREV,annual_inputs=INPUT,numerical_contract={**NUM,'provenance_ref':''})
    def test_transition_fail_closed(self):
        with self.assertRaisesRegex(GatePreflightError,'B_DEPENDENT_TRANSITION_UNSUPPORTED'):
            preflight(year=2026,initial_state=STATE,initial_contract=INITIAL,numerical_contract=NUM,transition_requested=True)
    def test_nonfinite_input_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'C_INPUT_INVALID'):
            preflight(year=2027,previous_state=STATE,previous_finalization=PREV,annual_inputs={**INPUT,'risk_shock':float('nan')},numerical_contract=NUM)

if __name__=='__main__': unittest.main()
