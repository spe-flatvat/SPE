import tempfile
import unittest
from pathlib import Path
from engine.m19_guarded_runner import run_year_guarded
from engine.m19_gate_preflight import GatePreflightError
from engine.m19_slice_a import RunContext, SliceAStore
from engine.m19_m10_adapter import advance_one_year
from tests.test_gate_preflight import STATE, INITIAL, NUM, INPUT

class GuardedRunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=SliceAStore(str(Path(self.tmp.name)/'store.db'))
        self.ctx=RunContext('exec-fixture','path-fixture','policy-fixture',
            'fixture-ic','fixture-only-not-real','fixture-nc')
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def initial(self,**kw):
        return run_year_guarded(self.store,self.ctx,2026,initial_state=STATE,
            initial_contract=INITIAL,numerical_contract=NUM,
            attempt_id='initial',**kw)
    def next(self,**kw):
        return run_year_guarded(self.store,self.ctx,2027,annual_inputs=INPUT,
            numerical_contract=NUM,calculator=advance_one_year,
            attempt_id='next',**kw)
    def test_context_numerical_contract_mismatch_no_write(self):
        with self.assertRaisesRegex(GatePreflightError, 'C_NUMERICAL_CONTRACT_CONTEXT_MISMATCH'):
            run_year_guarded(self.store,self.ctx,2026,initial_state=STATE,
                initial_contract=INITIAL,numerical_contract={**NUM,'contract_id':'other'},
                attempt_id='bad-numeric')
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],0)

    def test_context_initial_contract_mismatch_no_write(self):
        with self.assertRaisesRegex(GatePreflightError, 'A_INITIAL_CONTRACT_CONTEXT_MISMATCH'):
            run_year_guarded(self.store,self.ctx,2026,initial_state=STATE,
                initial_contract={**INITIAL,'contract_id':'other'},numerical_contract=NUM,
                attempt_id='bad-initial')
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],0)

    def test_context_approval_mismatch_no_write(self):
        with self.assertRaisesRegex(GatePreflightError, 'A_INITIAL_CONTRACT_CONTEXT_MISMATCH'):
            run_year_guarded(self.store,self.ctx,2026,initial_state=STATE,
                initial_contract={**INITIAL,'approval_id':'other'},numerical_contract=NUM,
                attempt_id='bad-approval')
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],0)

    def test_guarded_2026_and_2027(self):
        self.assertTrue(self.initial()[2]);self.assertTrue(self.next()[2])
        self.assertEqual(self.store.read(self.ctx,2027)[0]['year'],2027)
    def test_missing_approval_fails_before_write(self):
        with self.assertRaises(GatePreflightError):
            run_year_guarded(self.store,self.ctx,2026,initial_state=STATE,
                initial_contract={**INITIAL,'approval_id':''},numerical_contract=NUM,
                attempt_id='bad')
        self.assertEqual(self.store.db.execute('select count(*) from attempts').fetchone()[0],0)
    def test_missing_numerical_evidence_fails_before_write(self):
        self.initial()
        with self.assertRaises(GatePreflightError):
            run_year_guarded(self.store,self.ctx,2027,annual_inputs=INPUT,
                numerical_contract={**NUM,'coverage_ref':''},
                calculator=advance_one_year,attempt_id='bad')
        self.assertIsNone(self.store.read(self.ctx,2027))
    def test_switch_rejected_even_with_valid_initial_contract(self):
        with self.assertRaisesRegex(GatePreflightError,'B_DEPENDENT'):
            self.initial(transition_requested=True)
        self.assertIsNone(self.store.read(self.ctx,2026))
    def test_prior_state_must_be_finalized(self):
        with self.assertRaisesRegex(GatePreflightError,'A_PREVIOUS'):
            self.next()
    def test_corrupted_previous_state_rejected(self):
        self.initial()
        self.store.db.execute("UPDATE annual SET result_digest='tampered' WHERE year=2026")
        self.store.db.commit()
        with self.assertRaisesRegex(Exception,'digest mismatch'):
            self.next()
    def test_no_2025_state_fabrication(self):
        with self.assertRaises(GatePreflightError):
            run_year_guarded(self.store,self.ctx,2025,attempt_id='bad',
                numerical_contract=NUM)

if __name__=='__main__': unittest.main()
