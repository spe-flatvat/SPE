import tempfile, unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'engine'))
from m19_slice_a import SliceAStore,RunContext,run_year,ConflictError,ContractError
CTX=RunContext('exec','F','policy','initial','approval','input')
INIT={'year':2026,'real_gdp':580.0,'nominal_gdp':600.0}
def calc(s,i):return {'year':s['year']+1,'real_gdp':s['real_gdp']+i['delta'],'nominal_gdp':s['nominal_gdp']+i['delta']}
class IntegrityTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.s=SliceAStore(str(Path(self.t.name)/'test.db'))
  run_year(self.s,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='init')
 def tearDown(self):self.s.close();self.t.cleanup()
 def test_detect_stored_result_tamper(self):
  self.s.db.execute("UPDATE annual SET result_json=? WHERE year=2026", ('{"year":2026}',));self.s.db.commit()
  with self.assertRaises(ConflictError):self.s.read(CTX,2026)
 def test_attempt_owner_mismatch_rejected(self):
  self.s.attempt(CTX,2027,'attempt','PENDING',None,None)
  other=RunContext('other','F','policy','initial','approval','input')
  with self.assertRaises(ConflictError):self.s.finalize(other,2027,{'year':2027},'attempt',None)
  self.assertEqual(self.s.db.execute('SELECT count(*) FROM annual WHERE year=2027').fetchone()[0],0)
 def test_attempt_contract_mismatch_rejected(self):
  self.s.attempt(CTX,2027,'attempt','PENDING',None,None)
  changed=RunContext('exec','F','policy','initial','approval','changed')
  with self.assertRaises(ConflictError):self.s.finalize(changed,2027,{'year':2027},'attempt',None)
 def test_failed_attempt_cannot_finalize(self):
  self.s.attempt(CTX,2027,'attempt','FAILED',None,'reason')
  with self.assertRaises(ConflictError):self.s.finalize(CTX,2027,{'year':2027},'attempt',None)
 def test_non_string_ref_fails_closed(self):
  bad=RunContext('exec','F','policy','initial',None,'input')
  with self.assertRaises(ContractError):bad.validate()
if __name__=='__main__':unittest.main()
