import unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'engine'))
from m19_m10_adapter import advance_one_year, annual_to_m10_result
from m19_slice_a import SliceAStore, RunContext, run_year
import tempfile

INIT={'year':2026,'real_gdp':580.0,'nominal_gdp':600.0,'tax_revenue':80.0,
      'expenditure':108.0,'population':121_500_000,'deaths':1_590_000,'births':640_000}
I27={'risk_shock':0.05,'aging_drag':-0.005,'tax_elasticity':1.5,'expenditure_growth':0.025}
I28={**I27,'risk_shock':0.0}
CTX=RunContext('fixture-m10','F','fixture-policy','fixture-initial','fixture-approval','fixture-input')
class TestAdapter(unittest.TestCase):
    def test_2027_known_m10_assertions(self):
        r=advance_one_year(INIT,I27)
        self.assertEqual(r['year'],2027)
        self.assertAlmostEqual(r['population'],120_510_150)
        self.assertAlmostEqual(r['real_gdp'],551.8436,places=4)
        self.assertAlmostEqual(r['nominal_gdp'],582.8727,places=4)
        self.assertAlmostEqual(r['tax_revenue'],76.5745,places=4)
        self.assertAlmostEqual(r['expenditure'],110.7)
    def test_2028_2029_and_store(self):
        with tempfile.TemporaryDirectory() as td:
            s=SliceAStore(str(Path(td)/'state.db'))
            try:
                states={}
                for y,initial,inp in ((2026,INIT,None),(2027,None,I27),(2028,None,I28),(2029,None,I28)):
                    r,_,_=run_year(s,CTX,y,initial_state=initial,annual_inputs=inp,
                                   calculator=advance_one_year,attempt_id=f'a{y}')
                    states[y]=r
                self.assertEqual(list(states),[2026,2027,2028,2029])
                self.assertEqual(s.db.execute('SELECT COUNT(*) FROM year_end').fetchone()[0],4)
                data=annual_to_m10_result(states)
                self.assertEqual(list(data['years']),['2026','2027','2028','2029'])
                self.assertEqual(data['years']['2029']['bonds'],max(states[2029]['expenditure']-states[2029]['tax_revenue'],0))
            finally:s.close()
    def test_reject_bad_input(self):
        with self.assertRaises(ValueError):advance_one_year(INIT,{'risk_shock':0.0})
    def test_no_success_on_injected_crash(self):
        with tempfile.TemporaryDirectory() as td:
            s=SliceAStore(str(Path(td)/'state.db'))
            try:
                run_year(s,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='init')
                with self.assertRaises(RuntimeError):
                    run_year(s,CTX,2027,initial_state=None,annual_inputs=I27,calculator=advance_one_year,
                             attempt_id='crash',fail_before_commit=True)
                self.assertEqual(s.db.execute("SELECT status FROM attempts WHERE attempt_id='crash'").fetchone()[0],'PENDING')
                self.assertIsNone(s.read(CTX,2027))
            finally:s.close()
if __name__=='__main__':unittest.main()
