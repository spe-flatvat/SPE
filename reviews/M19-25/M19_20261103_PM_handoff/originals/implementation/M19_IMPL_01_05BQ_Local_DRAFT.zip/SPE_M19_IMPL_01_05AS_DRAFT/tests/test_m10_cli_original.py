"""Fixed-commit Git-blob-verified original M10 CLI and M18 integration tests."""
import copy
import json
import hashlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / 'reference'
sys.path.insert(0, str(ROOT))
from engine.m19_m10_adapter import advance_one_year, annual_to_m10_result

EXPECTED_BLOBS = {
 'engine/m10_results.py':'f87d09ae6be51986aea984da4e52a167497b9d9e',
 'engine/prototype.py':'71706c7d7d900cdffabd893aed8b9f82e6c5657f',
 'engine/m13_input_validate.py':'d31de0aa278e2c71afbceb5cac1830d76e203619',
 'engine/m14_wage_anchor.py':'d98bef72dc763947073970fd0ff9da0dcd7e867c',
 'engine/m17_gini_anchor.py':'6615cfbbb59935625dfe4a32a71dfb443c49f2b4',
 'scenarios/m8_baseline.json':'0c43c8ba032ed818796bb135bd8bdb2a38267da7',
 'engine/m18_evaluate.py':'d9455f6150dd37e05af2e78cde175bec0d4cbc7e',
 'engine/m12_validate.py':'aa48e4014f6935c1810bf0fd67d3fdb67f7abda5',
 'engine/m16_result_validate.py':'a948990ab9b09d79dfd0a72f7082eb37ecdcba70',
 'engine/m17_result_validate.py':'da35ab1c857582894fa50129074e2b904a263e0c',
}

def original_cli(path=None):
    cmd=[sys.executable, str(REF/'engine/m10_results.py')]
    if path is not None: cmd.append(str(path))
    run=subprocess.run(cmd,cwd=REF,capture_output=True,text=True,timeout=10,check=True)
    return json.loads(run.stdout)

class OriginalM10CLI(unittest.TestCase):
    def test_all_original_blob_ids(self):
        for name, expected in EXPECTED_BLOBS.items():
            with self.subTest(name=name):
                b=(REF/name).read_bytes()
                actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
                self.assertEqual(actual,expected)

    def test_baseline_entire_json_exact_match(self):
        original=original_cli()
        scenario=json.loads((REF/'scenarios/m8_baseline.json').read_text())
        states={2026:{k:v for k,v in original['years']['2026'].items() if k!='bonds'}}
        for year, inputs in scenario['annual_inputs'].items():
            states[int(year)]=advance_one_year(states[int(year)-1],inputs)
        adapter=annual_to_m10_result(states,scenario='m8_baseline.json',profile=scenario['profile'])
        self.assertEqual(original,adapter)
        self.assertEqual(list(original['years']),['2026','2027','2028','2029'])

    def test_original_m10_to_original_m18(self):
        original=original_cli()
        code='import json,sys;from m18_evaluate import evaluate_result;d=json.load(sys.stdin);print(json.dumps(evaluate_result(d)))'
        run=subprocess.run([sys.executable,'-c',code],cwd=REF/'engine',input=json.dumps(original),capture_output=True,text=True,timeout=10,check=True)
        evaluation=json.loads(run.stdout)
        self.assertEqual(evaluation['start_year'],2026)
        self.assertEqual(evaluation['end_year'],2029)
        self.assertFalse(evaluation['is_2055_endpoint'])
        self.assertEqual(evaluation['real_gdp_endpoint'],original['years']['2029']['real_gdp'])
        self.assertEqual(evaluation['bond_issuance_endpoint'],original['years']['2029']['bonds'])

    def test_original_m18_rejects_tampered_bonds(self):
        original=original_cli()
        original['years']['2029']['bonds']+=1
        code='import json,sys;from m18_evaluate import evaluate_result;evaluate_result(json.load(sys.stdin))'
        run=subprocess.run([sys.executable,'-c',code],cwd=REF/'engine',input=json.dumps(original),capture_output=True,text=True,timeout=10)
        self.assertNotEqual(run.returncode,0)
        self.assertIn('Bond mismatch',run.stderr)

    def test_original_cli_wage_gini_schema(self):
        scenario=json.loads((REF/'scenarios/m8_baseline.json').read_text())
        scenario['wage_anchors']={'2026':100.0,'2029':110.0}
        scenario['gini_anchors']={'2026':0.3,'2029':0.32}
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'anchored.json';p.write_text(json.dumps(scenario))
            original=original_cli(p)
        self.assertEqual(original['schema_version'],'m17.1')
        self.assertEqual(original['years']['2029']['real_median_wage'],110.0)
        self.assertEqual(original['years']['2029']['gini_coefficient'],0.32)
        code='import json,sys;from m18_evaluate import evaluate_result;print(json.dumps(evaluate_result(json.load(sys.stdin))))'
        run=subprocess.run([sys.executable,'-c',code],cwd=REF/'engine',input=json.dumps(original),capture_output=True,text=True,timeout=10,check=True)
        self.assertEqual(json.loads(run.stdout)['gini_coefficient_endpoint'],0.32)

if __name__=='__main__': unittest.main()
