import unittest
from engine.m19_m10_adapter import advance_one_year,annual_to_m10_result
from engine.m19_m18_fixture import validate_m10_fixture,evaluate_m18_fixture

BASE=dict(year=2026,real_gdp=580.,nominal_gdp=600.,tax_revenue=80.,expenditure=108.,population=121500000.,deaths=1590000.,births=640000.)
INPUT=dict(risk_shock=.05,aging_drag=-.005,tax_elasticity=1.5,expenditure_growth=.025)

def make():
    states={2026:BASE}
    for year in range(2027,2030):
        inputs={**INPUT,'risk_shock': .05 if year==2027 else 0.}
        states[year]=advance_one_year(states[year-1],inputs)
    return annual_to_m10_result(states,scenario='m8_baseline.json',profile='provisional_m7_reproduction')

class M18FixtureTests(unittest.TestCase):
    def test_baseline_shape_and_evaluation(self):
        data=make(); self.assertEqual(len(validate_m10_fixture(data)),4)
        result=evaluate_m18_fixture(data)
        self.assertEqual((result['start_year'],result['end_year'],result['is_2055_endpoint']),(2026,2029,False))
        self.assertAlmostEqual(result['real_gdp_endpoint'],data['years']['2029']['real_gdp'])
        self.assertAlmostEqual(result['bond_issuance_endpoint'],data['years']['2029']['bonds'])
    def test_reject_bond_mismatch(self):
        data=make(); data['years']['2028']['bonds']+=1
        with self.assertRaises(ValueError): evaluate_m18_fixture(data)
    def test_reject_missing_year(self):
        data=make(); del data['years']['2028']
        with self.assertRaises(ValueError): evaluate_m18_fixture(data)
    def test_reject_invalid_start(self):
        data=make(); del data['years']['2026']
        with self.assertRaises(ValueError): evaluate_m18_fixture(data)
    def test_reject_nan(self):
        data=make(); data['years']['2029']['nominal_gdp']=float('nan')
        with self.assertRaises(ValueError): evaluate_m18_fixture(data)
