"""Original M18 with original M12/M16/M17 validator dependencies."""
import importlib
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
from engine.m19_m18_fixture import evaluate_m18_fixture
from tests.test_m18_fixture import make

REF = Path(__file__).resolve().parents[1] / 'reference' / 'engine'

class OriginalFullM18Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with patch.dict(sys.modules, {k:None for k in ['m18_evaluate','m12_validate','m16_result_validate','m17_result_validate']}):
            # patch None would prevent imports; remove entries instead.
            pass
        sys.path.insert(0,str(REF))
        cls.m18 = importlib.import_module('m18_evaluate')

    @classmethod
    def tearDownClass(cls):
        sys.path.remove(str(REF))
        for k in ['m18_evaluate','m12_validate','m16_result_validate','m17_result_validate']:
            sys.modules.pop(k,None)

    def test_m10_original_dependencies_match_fixture(self):
        data=make()
        self.assertEqual(self.m18.evaluate_result(data),evaluate_m18_fixture(data))

    def test_m16_original_wage_schema(self):
        data=make();data['schema_version']='m16.1'
        for state in data['years'].values():state['real_median_wage']=300.0
        result=self.m18.evaluate_result(data)
        self.assertEqual(result['real_median_wage_endpoint'],300.0)

    def test_m17_original_gini_schema(self):
        data=make();data['schema_version']='m17.1'
        for state in data['years'].values():state['gini_coefficient']=0.3
        result=self.m18.evaluate_result(data)
        self.assertEqual(result['gini_coefficient_endpoint'],0.3)

    def test_original_rejects_inconsistent_wage(self):
        data=make();data['schema_version']='m17.1'
        for state in data['years'].values():state['gini_coefficient']=0.3
        data['years']['2027']['real_median_wage']=300.0
        with self.assertRaises(ValueError):self.m18.evaluate_result(data)

    def test_original_rejects_extra_indicator(self):
        data=make();data['years']['2028']['invented']=10
        with self.assertRaises(ValueError):self.m18.evaluate_result(data)
