"""Execute blob-verified original M18 evaluator with explicitly substituted validators.
This is NOT SA-09 full original dependency regression.
"""
import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch
from engine.m19_m18_fixture import validate_m10_fixture, evaluate_m18_fixture
from tests.test_m18_fixture import make

REF = Path(__file__).resolve().parents[1] / 'reference/engine/m18_evaluate.py'

def load_original_with_fixture_validators():
    modules = {}
    for module, symbol in [('m12_validate','validate_result'),('m16_result_validate','validate_m16_result'),('m17_result_validate','validate_m17_result')]:
        shim=types.ModuleType(module)
        setattr(shim,symbol,validate_m10_fixture)
        modules[module]=shim
    with patch.dict(sys.modules,modules):
        spec=importlib.util.spec_from_file_location('m18_original_verified',REF)
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    return module.evaluate_result

class OriginalM18FunctionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.evaluate=staticmethod(load_original_with_fixture_validators())
    def test_original_equals_fixture_evaluation(self):
        self.assertEqual(self.evaluate(make()),evaluate_m18_fixture(make()))
    def test_original_rejects_bond_mismatch(self):
        data=make();data['years']['2029']['bonds']+=10
        with self.assertRaises(ValueError):self.evaluate(data)
    def test_original_rejects_missing_year(self):
        data=make();del data['years']['2028']
        with self.assertRaises(ValueError):self.evaluate(data)
    def test_original_rejects_wrong_start(self):
        data=make();del data['years']['2026']
        with self.assertRaises(ValueError):self.evaluate(data)
    def test_original_rejects_nan(self):
        data=make();data['years']['2028']['nominal_gdp']=float('nan')
        with self.assertRaises(ValueError):self.evaluate(data)
