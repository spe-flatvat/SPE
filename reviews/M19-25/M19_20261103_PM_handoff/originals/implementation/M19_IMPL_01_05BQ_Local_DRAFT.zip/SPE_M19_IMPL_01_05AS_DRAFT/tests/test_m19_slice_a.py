import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"engine"))
from m19_slice_a import SliceAStore, RunContext, run_year, ContractError, ConflictError

CTX=RunContext("fixture-execution","F","fixture-policy","fixture-initial","fixture-approval","fixture-annual")
INIT={"year":2026,"real_gdp":580.0,"nominal_gdp":600.0}

def calc(state, inputs):
    return {"year":state["year"]+1,"real_gdp":state["real_gdp"]+inputs["delta"],
            "nominal_gdp":state["nominal_gdp"]+inputs["delta"]}

class TestSliceA(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.s=SliceAStore(str(Path(self.tmp.name)/"state.db"))
    def tearDown(self):
        self.s.close();self.tmp.cleanup()
    def init(self):
        return run_year(self.s,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id="a26")
    def test_sa01_initial(self):
        result,hash_,new=self.init();self.assertTrue(new);self.assertEqual(result,INIT)
        self.assertEqual(self.s.db.execute("SELECT count(*) FROM year_end").fetchone()[0],1)
    def test_sa02_carry_forward(self):
        self.init();result,_,_=run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":2},calculator=calc,attempt_id="a27")
        self.assertEqual(result["real_gdp"],582)
    def test_sa03_missing_c(self):
        self.init()
        with self.assertRaises(ContractError):run_year(self.s,CTX,2027,initial_state=None,annual_inputs=None,calculator=calc,attempt_id="a27")
        self.assertIsNone(self.s.read(CTX,2027))
    def test_sa04_gate_b(self):
        self.init();self.assertEqual(self.s.db.execute("SELECT outcome FROM gates WHERE gate='B'").fetchone()[0],"NOT_APPLICABLE")
    def test_sa05_failed_retry(self):
        self.init()
        def broken(s,i):raise ValueError("fixture")
        with self.assertRaises(ValueError):run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":2},calculator=broken,attempt_id="failed")
        run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":2},calculator=calc,attempt_id="success")
        self.assertEqual(self.s.db.execute("SELECT count(*) FROM attempts WHERE year=2027").fetchone()[0],2)
        self.assertEqual(self.s.db.execute("SELECT count(*) FROM annual WHERE year=2027").fetchone()[0],1)
    def test_sa06_idempotence_and_conflict(self):
        self.init();r=run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":2},calculator=calc,attempt_id="first")
        r2=run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":2},calculator=calc,attempt_id="second")
        self.assertFalse(r2[2]);self.assertEqual(r[1],r2[1])
        with self.assertRaises(ConflictError):run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":3},calculator=calc,attempt_id="third")
    def test_sa07_atomic_crash(self):
        self.init()
        with self.assertRaises(RuntimeError):run_year(self.s,CTX,2027,initial_state=None,annual_inputs={"delta":2},calculator=calc,attempt_id="crash",fail_before_commit=True)
        self.assertIsNone(self.s.read(CTX,2027))
        self.assertEqual(self.s.db.execute("SELECT count(*) FROM year_end WHERE year=2027").fetchone()[0],0)
    def test_reject_unapproved_mode(self):
        bad=RunContext("a","b","c","d","e","f",mode="configurable")
        with self.assertRaises(ContractError):run_year(self.s,bad,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id="x")

if __name__=="__main__":unittest.main()
