import hashlib
import json
from engine.m19_manifest_entry import run_year_manifest
from engine.m19_gate_preflight import GatePreflightError
from engine.m19_m10_adapter import advance_one_year
from tests.test_pinned_entry import PinnedEntryTests
from tests.test_gate_preflight import STATE, INPUT

class ManifestEntryTests(PinnedEntryTests):
    def setUp(self):
        super().setUp()
        self.manifest={'schema_version':'m19-fixture-manifest-v1',
            'initial':{'filename':self.ip.name,'sha256':self.ih},
            'numerical':{'filename':self.np.name,'sha256':self.nh},
            'context':{key:getattr(self.ctx,key) for key in
                ('execution_id','path_id','effective_policy_ref','initial_contract_ref',
                 'initial_approval_ref','input_contract_ref','start_year','mode')}}
        self.repin()
    def repin(self):
        raw=json.dumps(self.manifest,sort_keys=True).encode()
        (self.base/'manifest.json').write_bytes(raw)
        self.pin=hashlib.sha256(raw).hexdigest()
    def run_manifest(self,year=2026,**kw):
        p=dict(manifest_dir=self.base,manifest_sha256=self.pin,
               attempt_id='manifest-'+str(year),initial_state=STATE if year==2026 else None,
               annual_inputs=INPUT if year==2027 else None,
               calculator=advance_one_year if year==2027 else None)
        p.update(kw)
        return run_year_manifest(self.store,self.ctx,year,**p)
    def test_manifest_two_years(self):
        self.assertTrue(self.run_manifest()[2]);self.assertTrue(self.run_manifest(2027)[2])
    def test_manifest_mutation_rejected(self):
        (self.base/'manifest.json').write_text('{}')
        with self.assertRaisesRegex(GatePreflightError,'PIN_CONTENT_MISMATCH'):self.run_manifest()
        self.assertEqual(self.store.db.execute('select count(*) from attempts').fetchone()[0],0)
    def test_manifest_context_mismatch(self):
        self.manifest['context']['execution_id']='other';self.repin()
        with self.assertRaisesRegex(GatePreflightError,'MANIFEST_CONTEXT_MISMATCH'):self.run_manifest()
    def test_manifest_traversal(self):
        self.manifest['initial']['filename']='../initial.json';self.repin()
        with self.assertRaisesRegex(GatePreflightError,'MANIFEST_INVALID_FILENAME'):self.run_manifest()
    def test_manifest_wrong_contract_digest(self):
        self.manifest['numerical']['sha256']='0'*64;self.repin()
        with self.assertRaisesRegex(GatePreflightError,'PIN_CONTENT_MISMATCH'):self.run_manifest()
    def test_manifest_unexpected_fields(self):
        self.manifest['owner_approved']=True;self.repin()
        with self.assertRaisesRegex(GatePreflightError,'MANIFEST_INVALID_SCHEMA'):self.run_manifest()
    def test_manifest_collision(self):
        self.manifest['numerical']['filename']=self.ip.name;self.repin()
        with self.assertRaisesRegex(GatePreflightError,'MANIFEST_COLLIDING_FILES'):self.run_manifest()
    def test_manifest_symlink_contract(self):
        link=self.base/'alias.json';link.symlink_to(self.ip)
        self.manifest['initial']['filename']=link.name;self.repin()
        with self.assertRaisesRegex(GatePreflightError,'PIN_UNSAFE_PATH'):self.run_manifest()
