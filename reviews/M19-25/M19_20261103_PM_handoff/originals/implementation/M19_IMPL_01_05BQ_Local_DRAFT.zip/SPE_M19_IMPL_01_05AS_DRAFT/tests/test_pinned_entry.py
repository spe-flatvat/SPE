import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from engine.m19_pinned_entry import load_pinned_contract, run_year_pinned
from engine.m19_gate_preflight import GatePreflightError
from engine.m19_slice_a import RunContext, SliceAStore, digest
from engine.m19_m10_adapter import advance_one_year
from tests.test_gate_preflight import STATE, INITIAL, NUM, INPUT

class PinnedEntryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.base=Path(self.tmp.name)
        self.store=SliceAStore(str(self.base/'store.db'))
        self.ctx=RunContext('pin-exec','pin-path','policy-fixture','fixture-ic','fixture-only-not-real','fixture-nc')
        self.ic={**INITIAL,'state_digest':digest(STATE)}
        self.nc={**NUM,'policy_ref':'policy-fixture','covered_years':[2026,2027],
                 'initial_state_digest':digest(STATE),'annual_input_digests':{'2027':digest(INPUT)}}
        self.ip,self.ih=self.write('initial.json',self.ic)
        self.np,self.nh=self.write('numerical.json',self.nc)
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def write(self,name,obj):
        p=self.base/name
        raw=json.dumps(obj,sort_keys=True).encode()
        p.write_bytes(raw)
        return p,hashlib.sha256(raw).hexdigest()
    def execute_year(self,year,**kw):
        params=dict(initial_contract_path=self.ip,initial_contract_sha256=self.ih,
                    numerical_contract_path=self.np,numerical_contract_sha256=self.nh,
                    attempt_id='p'+str(year))
        params.update(kw)
        return run_year_pinned(self.store,self.ctx,year,**params)
    def test_two_year_pinned_run(self):
        self.assertTrue(self.execute_year(2026,initial_state=STATE)[2])
        self.assertTrue(self.execute_year(2027,annual_inputs=INPUT,calculator=advance_one_year)[2])
    def test_changed_file_fails_before_attempt(self):
        self.np.write_text('{}')
        with self.assertRaisesRegex(GatePreflightError,'PIN_CONTENT_MISMATCH'):
            self.execute_year(2026,initial_state=STATE)
        self.assertEqual(self.store.db.execute('select count(*) from attempts').fetchone()[0],0)
    def test_wrong_pin_fails(self):
        with self.assertRaisesRegex(GatePreflightError,'PIN_CONTENT_MISMATCH'):
            self.execute_year(2026,initial_state=STATE,numerical_contract_sha256='0'*64)
    def test_bad_digest_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'PIN_INVALID_DIGEST'):
            load_pinned_contract(self.ip,'bad')
    def test_duplicate_keys_rejected(self):
        p=self.base/'dup.json'; raw=b'{"contract_id":"a","contract_id":"b"}';p.write_bytes(raw)
        with self.assertRaisesRegex(GatePreflightError,'PIN_DUPLICATE_JSON_KEY'):
            load_pinned_contract(p,hashlib.sha256(raw).hexdigest())
    def test_nonfinite_rejected(self):
        p=self.base/'nan.json';raw=b'{"x":NaN}';p.write_bytes(raw)
        with self.assertRaisesRegex(GatePreflightError,'PIN_INVALID_JSON'):
            load_pinned_contract(p,hashlib.sha256(raw).hexdigest())
    def test_symlink_rejected(self):
        p=self.base/'link.json';p.symlink_to(self.ip)
        with self.assertRaisesRegex(GatePreflightError,'PIN_UNSAFE_PATH'):
            load_pinned_contract(p,self.ih)
    def test_valid_pin_does_not_authenticate_approval(self):
        self.ic['approval_id']='fixture-only-another-fake-approval'
        p,h=self.write('new_initial.json',self.ic)
        with self.assertRaisesRegex(GatePreflightError,'A_INITIAL_CONTRACT_CONTEXT_MISMATCH'):
            self.execute_year(2026,initial_state=STATE,initial_contract_path=p,initial_contract_sha256=h)
    def test_transition_remains_rejected(self):
        with self.assertRaisesRegex(GatePreflightError,'B_DEPENDENT_TRANSITION_UNSUPPORTED'):
            self.execute_year(2026,initial_state=STATE,transition_requested=True)

if __name__=='__main__':unittest.main()
