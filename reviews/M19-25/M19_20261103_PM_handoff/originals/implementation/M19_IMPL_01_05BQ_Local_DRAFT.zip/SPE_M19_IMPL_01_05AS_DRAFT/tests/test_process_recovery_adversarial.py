"""05BM-05BN: real process interruption and fenced pending recovery."""
import os
import subprocess
import sys
import time
import unittest
from engine.m19_slice_a import ConflictError
from engine.m19_worker_lease import acquire, release
from engine.m19_fenced_recovery import fenced_recover_pending
from tests import test_strict_runtime_adversarial as adv

class ProcessRecoveryAdversarialTests(adv.StrictRuntimeAdversarialTests):
    def test_pending_recovered_only_by_new_fenced_owner(self):
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        self.a.attempt(self.ctx,2027,'orphan-2027','PENDING',None,None,fence=('A',g))
        self.a.db.execute('UPDATE worker_leases SET expires_at=0 WHERE year=2027'); self.a.db.commit()
        g2=acquire(self.b.db,self.ctx,2027,'B')
        with self.assertRaises(ConflictError):
            fenced_recover_pending(self.a,self.ctx,2027,'A',g)
        self.assertEqual(fenced_recover_pending(self.b,self.ctx,2027,'B',g2),1)
        self.assertEqual(fenced_recover_pending(self.b,self.ctx,2027,'B',g2),0)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='orphan-2027'").fetchone()[0],'FAILED')
        self.assertTrue(self._run(self.b,2027,('B',g2),attempt_id='after-recovery')[2])
    def test_killed_process_rolls_back_uncommitted_sqlite_write(self):
        self._prepare()
        dbpath=self.a.db.execute('PRAGMA database_list').fetchone()[2]
        script='import sqlite3,sys,time\nc=sqlite3.connect(sys.argv[1],timeout=5)\nc.execute(\'BEGIN IMMEDIATE\')\nc.execute("INSERT INTO attempts VALUES(?,?,?,?,?,?,?,?)",(\'killed-pending\',\'exec-fixture\',\'path-fixture\',2027,\'fixture-nc\',\'PENDING\',None,None))\nprint(\'LOCKED\',flush=True)\ntime.sleep(60)\n'
        proc=subprocess.Popen([sys.executable,'-c',script,dbpath],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            self.assertEqual(proc.stdout.readline().strip(),'LOCKED')
        finally:
            proc.kill();proc.communicate(timeout=5)
        self.assertIsNone(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='killed-pending'").fetchone())
        g=acquire(self.a.db,self.ctx,2027,'A')
        self.assertTrue(self._run(self.a,2027,('A',g))[2])
    def test_other_process_cannot_take_live_lease(self):
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        dbpath=self.a.db.execute('PRAGMA database_list').fetchone()[2]
        script="import sqlite3,sys\nfrom engine.m19_worker_lease import acquire\nfrom engine.m19_slice_a import RunContext,ConflictError\nc=sqlite3.connect(sys.argv[1],timeout=3)\nctx=RunContext('exec-fixture','path-fixture','policy-fixture','fixture-ic','fixture-only-not-real','fixture-nc')\ntry:\n acquire(c,ctx,2027,'B')\nexcept ConflictError:\n print('REJECTED');sys.exit(0)\nprint('UNEXPECTED_ACQUIRE');sys.exit(2)\n"
        cp=subprocess.run([sys.executable,'-c',script,dbpath],capture_output=True,text=True,timeout=10)
        self.assertEqual(cp.returncode,0,cp.stderr+cp.stdout)
        self.assertIn('REJECTED',cp.stdout)
        self.assertTrue(self._run(self.a,2027,('A',g))[2])

for _name in vars(adv.StrictRuntimeAdversarialTests):
    if _name.startswith('test_'): setattr(ProcessRecoveryAdversarialTests,_name,None)

class FinalizationReconciliationTests(adv.StrictRuntimeAdversarialTests):
    def test_pending_with_finalized_year_requires_explicit_reconciliation(self):
        from engine.m19_fenced_recovery import fenced_reconcile_finalized
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        self.assertTrue(self._run(self.a,2027,('A',g))[2])
        self.a.attempt(self.ctx,2027,'stray-pending','PENDING',None,None,fence=('A',g))
        with self.assertRaises(ConflictError):
            fenced_recover_pending(self.a,self.ctx,2027,'A',g)
        self.assertEqual(fenced_reconcile_finalized(self.a,self.ctx,2027,'A',g),1)
        self.assertEqual(fenced_reconcile_finalized(self.a,self.ctx,2027,'A',g),0)
        self.assertEqual(self.a.db.execute("SELECT status FROM attempts WHERE attempt_id='stray-pending'").fetchone()[0],'FAILED')
        self.assertEqual(self.a.db.execute("SELECT count(*) FROM year_end WHERE year=2027").fetchone()[0],1)
    def test_stale_owner_cannot_reconcile_finalized_year(self):
        from engine.m19_fenced_recovery import fenced_reconcile_finalized
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        self.assertTrue(self._run(self.a,2027,('A',g))[2])
        self.a.db.execute('UPDATE worker_leases SET expires_at=0 WHERE year=2027'); self.a.db.commit()
        g2=acquire(self.b.db,self.ctx,2027,'B')
        with self.assertRaises(ConflictError):
            fenced_reconcile_finalized(self.a,self.ctx,2027,'A',g)
        self.assertEqual(fenced_reconcile_finalized(self.b,self.ctx,2027,'B',g2),0)

for _name in vars(adv.StrictRuntimeAdversarialTests):
    if _name.startswith('test_'): setattr(FinalizationReconciliationTests,_name,None)
