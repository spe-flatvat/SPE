import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'engine'))
from m19_slice_a import SliceAStore, RunContext, run_year, ConflictError, ContractError

CTX = RunContext('reconcile-exec', 'F', 'fixture-policy', 'fixture-initial', 'fixture-approval', 'fixture-input')
INIT = {'year': 2026, 'real_gdp': 580.0, 'nominal_gdp': 600.0}
def calc(s, i):
    return {'year': s['year'] + 1, 'real_gdp': s['real_gdp'] + i['delta'], 'nominal_gdp': s['nominal_gdp'] + i['delta']}

class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = SliceAStore(str(Path(self.tmp.name) / 'db.sqlite'))
        run_year(self.store, CTX, 2026, initial_state=INIT, annual_inputs=None, calculator=None, attempt_id='initial')
    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()
    def pending(self):
        with self.assertRaises(RuntimeError):
            run_year(self.store, CTX, 2027, initial_state=None, annual_inputs={'delta': 1}, calculator=calc, attempt_id='loser', fail_before_commit=True)
    def test_reconcile_losing_pending_after_winner(self):
        self.pending()
        result, result_hash, created = run_year(self.store, CTX, 2027, initial_state=None, annual_inputs={'delta': 1}, calculator=calc, attempt_id='winner')
        self.assertTrue(created)
        self.assertEqual(self.store.reconcile_after_finalization(CTX, 2027), 1)
        self.assertEqual(self.store.db.execute("SELECT status,reason FROM attempts WHERE attempt_id='loser'").fetchone(), ('FAILED', 'SUPERSEDED_BY_FINALIZED_YEAR'))
        self.assertEqual(self.store.db.execute("SELECT status FROM attempts WHERE attempt_id='winner'").fetchone(), ('SUCCEEDED',))
        self.assertEqual(self.store.read(CTX, 2027)[1], result_hash)
        self.assertEqual(self.store.reconcile_after_finalization(CTX, 2027), 0)
    def test_reject_unfinalized_year(self):
        self.pending()
        with self.assertRaises(ConflictError):
            self.store.reconcile_after_finalization(CTX, 2027)
        self.assertEqual(self.store.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone(), ('PENDING',))
    def test_reconcile_scope_isolation(self):
        self.pending()
        run_year(self.store, CTX, 2027, initial_state=None, annual_inputs={'delta': 1}, calculator=calc, attempt_id='winner')
        other = RunContext('other', 'F', 'p', 'i', 'a', 'x')
        with self.assertRaises(ConflictError):
            self.store.reconcile_after_finalization(other, 2027)
        self.assertEqual(self.store.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone(), ('PENDING',))
    def test_invalid_reason_rolls_back(self):
        self.pending()
        run_year(self.store, CTX, 2027, initial_state=None, annual_inputs={'delta': 1}, calculator=calc, attempt_id='winner')
        with self.assertRaises(ContractError):
            self.store.reconcile_after_finalization(CTX, 2027, reason='')
        self.assertEqual(self.store.db.execute("SELECT status FROM attempts WHERE attempt_id='loser'").fetchone(), ('PENDING',))

if __name__ == '__main__': unittest.main()
