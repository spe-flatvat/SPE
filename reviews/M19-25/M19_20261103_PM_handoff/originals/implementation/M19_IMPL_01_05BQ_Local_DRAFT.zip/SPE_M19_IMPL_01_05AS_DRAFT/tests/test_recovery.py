import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'engine'))
from m19_slice_a import SliceAStore, RunContext, run_year, ConflictError

CTX=RunContext('recovery-exec','F','fixture-policy','fixture-initial','fixture-approval','fixture-input')
INIT={'year':2026,'real_gdp':580.0,'nominal_gdp':600.0}
def calc(s,i): return {'year':s['year']+1,'real_gdp':s['real_gdp']+i['delta'],'nominal_gdp':s['nominal_gdp']+i['delta']}

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.path=str(Path(self.temp.name)/'test.db'); self.s=SliceAStore(self.path)
        run_year(self.s,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='init')
    def tearDown(self):self.s.close();self.temp.cleanup()
    def crash(self):
        with self.assertRaises(RuntimeError):
            run_year(self.s,CTX,2027,initial_state=None,annual_inputs={'delta':1},calculator=calc,attempt_id='crash',fail_before_commit=True)
    def test_reopen_recovery_then_retry(self):
        self.crash();self.s.close();self.s=SliceAStore(self.path)
        self.assertEqual(self.s.recover_pending(CTX,2027),1)
        self.assertEqual(self.s.db.execute("SELECT status,reason FROM attempts WHERE attempt_id='crash'").fetchone(),('FAILED','RECOVERED_AFTER_INTERRUPTION'))
        self.assertEqual(self.s.recover_pending(CTX,2027),0)
        result,_,new=run_year(self.s,CTX,2027,initial_state=None,annual_inputs={'delta':1},calculator=calc,attempt_id='retry')
        self.assertTrue(new);self.assertEqual(result['year'],2027)
        self.assertEqual(self.s.db.execute('SELECT count(*) FROM annual WHERE year=2027').fetchone()[0],1)
        self.assertEqual(self.s.db.execute('SELECT count(*) FROM year_end WHERE year=2027').fetchone()[0],1)
    def test_recovery_scoped(self):
        self.crash()
        other=RunContext('other','F','p','i','a','x')
        self.assertEqual(self.s.recover_pending(other,2027),0)
        self.assertEqual(self.s.db.execute("SELECT status FROM attempts WHERE attempt_id='crash'").fetchone()[0],'PENDING')
    def test_duplicate_attempt_rejected(self):
        self.crash()
        with self.assertRaises(ConflictError):
            run_year(self.s,CTX,2027,initial_state=None,annual_inputs={'delta':1},calculator=calc,attempt_id='crash')
    def test_recovery_does_not_mutate_finalized(self):
        run_year(self.s,CTX,2027,initial_state=None,annual_inputs={'delta':1},calculator=calc,attempt_id='ok')
        self.assertEqual(self.s.recover_pending(CTX,2027),0)
        self.assertEqual(self.s.db.execute("SELECT status FROM attempts WHERE attempt_id='ok'").fetchone()[0],'SUCCEEDED')

if __name__=='__main__':unittest.main()
