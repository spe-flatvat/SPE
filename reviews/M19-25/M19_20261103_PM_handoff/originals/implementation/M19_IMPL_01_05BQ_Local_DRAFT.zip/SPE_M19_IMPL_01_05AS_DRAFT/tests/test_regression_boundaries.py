"""Additional source-derived M10 reference comparisons and M19 negative tests.
Not an execution of upstream M10 CLI or M18; does not satisfy SA-08/09.
"""
import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'engine'))
from m19_m10_adapter import advance_one_year
from m19_slice_a import SliceAStore, RunContext, run_year, ContractError, ConflictError

INIT={'year':2026,'real_gdp':580.0,'nominal_gdp':600.0,'tax_revenue':80.0,
      'expenditure':108.0,'population':121_500_000,'deaths':1_590_000,'births':640_000}
I27={'risk_shock':0.05,'aging_drag':-0.005,'tax_elasticity':1.5,'expenditure_growth':0.025}
I28={**I27,'risk_shock':0.0}
CTX=RunContext('extra-regression','F','fixture-policy','fixture-initial','fixture-approval','fixture-input')

def reference_advance(prev, inputs):
    """Independently written from fixed M10/prototype source; NOT upstream runtime."""
    deaths=prev['deaths']*1.015
    births=prev['births']*0.975*(1+0.15*0.0)
    population=prev['population']+(births-deaths)+0.0
    pop_growth=population/prev['population']-1
    labor=pop_growth+inputs['aging_drag']
    real_growth=0.01+0.0+0.0+0.0-inputs['risk_shock']+(1-0.35)*labor
    nominal_growth=real_growth+0.02+0.0+0.0
    real_gdp=prev['real_gdp']*(1+real_growth)
    nominal_gdp=prev['nominal_gdp']*(1+nominal_growth)
    revenue=min(prev['tax_revenue']*(1+nominal_growth*inputs['tax_elasticity']),nominal_gdp*0.30)
    return dict(year=prev['year']+1,real_gdp=real_gdp,nominal_gdp=nominal_gdp,
                tax_revenue=revenue,expenditure=prev['expenditure']*(1+inputs['expenditure_growth']),
                population=population,deaths=deaths,births=births)

class TestExtraRegression(unittest.TestCase):
    def test_all_fields_three_years_against_source_derived_reference(self):
        a=b=dict(INIT)
        for inputs in (I27,I28,I28):
            a=advance_one_year(a,inputs)
            b=reference_advance(b,inputs)
            self.assertEqual(set(a),set(b))
            for key in a:self.assertAlmostEqual(a[key],b[key],places=9,msg=f'{a["year"]}/{key}')

    def test_missing_previous_year_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            s=SliceAStore(str(Path(td)/'s.db'))
            try:
                with self.assertRaises(ContractError):run_year(s,CTX,2027,initial_state=None,annual_inputs=I27,calculator=advance_one_year,attempt_id='missing')
                self.assertEqual(s.db.execute('SELECT count(*) FROM annual').fetchone()[0],0)
            finally:s.close()

    def test_wrong_year_calculator_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            s=SliceAStore(str(Path(td)/'s.db'))
            try:
                run_year(s,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='init')
                with self.assertRaises(ContractError):run_year(s,CTX,2027,initial_state=None,annual_inputs=I27,calculator=lambda p,i:dict(p),attempt_id='bad')
                self.assertIsNone(s.read(CTX,2027))
            finally:s.close()

    def test_same_attempt_identity_across_paths_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            s=SliceAStore(str(Path(td)/'s.db'))
            try:
                run_year(s,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='global-id')
                other=RunContext('other-execution','N3','p','i','a','c')
                with self.assertRaises(ConflictError):run_year(s,other,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id='global-id')
            finally:s.close()

if __name__=='__main__':unittest.main()
