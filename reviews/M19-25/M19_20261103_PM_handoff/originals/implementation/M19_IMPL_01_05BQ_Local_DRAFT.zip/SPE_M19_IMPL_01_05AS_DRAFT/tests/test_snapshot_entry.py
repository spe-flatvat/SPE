"""05AA-05AD: verified contract snapshot survives file replacement after preflight."""
import json
import unittest
from unittest.mock import patch
import unittest
from tests.cli_fixture import CliFixtureMixin
from engine import m19_cli_entry

class SnapshotEntryTests(CliFixtureMixin, unittest.TestCase):
    def test_2026_file_change_after_lease_does_not_change_execution(self):
        original_acquire=m19_cli_entry.acquire
        def swap(db, ctx, year, owner_id):
            token=original_acquire(db,ctx,year,owner_id)
            self.ip.write_text('{}')
            self.np.write_text('{}')
            (self.base/'manifest.json').write_text('{}')
            return token
        with patch.object(m19_cli_entry,'acquire',side_effect=swap):
            result=m19_cli_entry.execute(db_path=self.db,manifest_dir=self.base,
                manifest_sha256=self.pin,year=2026,attempt_id='snap-2026')
        self.assertTrue(result['created'])

    def test_2027_file_change_after_lease_does_not_change_execution(self):
        self.assertEqual(self.cli().returncode,0)
        original_acquire=m19_cli_entry.acquire
        def swap(db, ctx, year, owner_id):
            token=original_acquire(db,ctx,year,owner_id)
            self.np.write_text('{}')
            return token
        with patch.object(m19_cli_entry,'acquire',side_effect=swap):
            result=m19_cli_entry.execute(db_path=self.db,manifest_dir=self.base,
                manifest_sha256=self.pin,year=2027,attempt_id='snap-2027')
        self.assertTrue(result['created'])

    def test_invalid_contract_before_lease_has_no_worker_lease_table(self):
        self.np.write_text('{}')
        with self.assertRaises(Exception):
            m19_cli_entry.execute(db_path=self.db,manifest_dir=self.base,
                manifest_sha256=self.pin,year=2026,attempt_id='snap-bad')
        self.assertFalse(self.db.exists())
