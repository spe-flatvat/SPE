import os
import tempfile
import unittest
from engine.m19_slice_a import RunContext, SliceAStore, ContractError
from engine.m19_strict_entry import run_year_strict
from engine.m19_worker_lease import ensure_lease_table, acquire

class StrictEntryTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix='.sqlite3')
        os.close(fd)
        self.store = SliceAStore(self.path)
        self.ctx = RunContext('execution','F','policy','initial','approval','numerical')
        ensure_lease_table(self.store.db)

    def tearDown(self):
        self.store.close()
        os.unlink(self.path)

    def _counts(self):
        return tuple(self.store.db.execute('SELECT count(*) FROM '+name).fetchone()[0]
                     for name in ('gates','attempts','annual','year_end'))

    def test_missing_fence_rejected_without_writes(self):
        for invalid in (None, (), ('worker',), ('worker', True), ('', 1)):
            with self.subTest(invalid=invalid):
                with self.assertRaises(ContractError):
                    run_year_strict(self.store, self.ctx, 2026, fence=invalid,
                                    attempt_id='attempt')
                self.assertEqual(self._counts(), (0,0,0,0))

    def test_stale_generation_rejected_without_writes(self):
        generation = acquire(self.store.db, self.ctx, 2026, 'worker', ttl=10, now=100)
        with self.assertRaises(Exception):
            run_year_strict(self.store, self.ctx, 2026, fence=('worker',generation+1),
                            attempt_id='attempt')
        self.assertEqual(self._counts(), (0,0,0,0))

    def test_valid_fence_reaches_contract_validation_without_writes(self):
        generation = acquire(self.store.db, self.ctx, 2026, 'worker')
        with self.assertRaises(Exception):
            run_year_strict(self.store, self.ctx, 2026, fence=('worker',generation),
                            attempt_id='attempt')
        self.assertEqual(self._counts(), (0,0,0,0))
