"""05BJ-05BL local DRAFT: atomicity, competing results, and lease recovery."""
import unittest
from engine.m19_slice_a import ConflictError
from engine.m19_worker_lease import acquire, release
from tests import test_strict_runtime_adversarial as adversarial
from engine.m19_m10_adapter import advance_one_year

class StrictExtendedFailureTests(adversarial.StrictRuntimeAdversarialTests):
    # Base tests intentionally not inherited as collected tests (see __test__ below).
    def test_crash_before_year_end_rolls_back_annual_and_recovers(self):
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        with self.assertRaisesRegex(RuntimeError,'Injected crash before year-end'):
            self._run(self.a,2027,('A',g),fail_before_commit=True)
        self.assertIsNone(self.a.read(self.ctx,2027))
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM annual WHERE year=2027').fetchone()[0],0)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM year_end WHERE year=2027').fetchone()[0],0)
        self.assertFalse(self.a.db.in_transaction)
        self.assertEqual(self.a.db.execute('SELECT status FROM attempts WHERE attempt_id=?',('attempt-2027',)).fetchone()[0],'PENDING')
        self.assertTrue(self._run(self.a,2027,('A',g),attempt_id='retry-2027')[2])
    def test_conflicting_result_rejected_and_original_preserved(self):
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        self.assertTrue(self._run(self.a,2027,('A',g))[2])
        prior=self.a.read(self.ctx,2027)
        def altered(state, inputs):
            result=advance_one_year(state,inputs)
            result['test-conflict']='different'
            return result
        with self.assertRaises(ConflictError):
            self._run(self.a,2027,('A',g),attempt_id='conflicting-attempt',calculator=altered)
        self.assertEqual(self.a.read(self.ctx,2027),prior)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM year_end WHERE year=2027').fetchone()[0],1)
    def test_stale_release_fails_and_new_owner_can_recover(self):
        self._prepare()
        g=acquire(self.a.db,self.ctx,2027,'A')
        self.a.db.execute('UPDATE worker_leases SET expires_at=0 WHERE year=2027');self.a.db.commit()
        next_g=acquire(self.b.db,self.ctx,2027,'B')
        self.assertEqual(next_g,g+1)
        with self.assertRaises(ConflictError): release(self.a.db,self.ctx,2027,'A',g)
        self.assertFalse(self.a.db.in_transaction)
        self.assertTrue(self._run(self.b,2027,('B',next_g),attempt_id='new-owner-attempt')[2])
        release(self.b.db,self.ctx,2027,'B',next_g)

# Prevent inherited adversarial tests from being collected twice.
for _name in list(vars(adversarial.StrictRuntimeAdversarialTests)):
    if _name.startswith("test_"):
        setattr(StrictExtendedFailureTests, _name, None)
