"""05BP local DRAFT: strict production facade rejects malformed fences without writes."""
import os
import tempfile
import unittest
from engine.m19_slice_a import RunContext, SliceAStore, ContractError
from engine.m19_execution_api import execute_year
from engine.m19_worker_lease import ensure_lease_table, acquire

class StrictFenceContractTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix='.sqlite3'); os.close(fd)
        self.store = SliceAStore(self.path)
        self.ctx = RunContext('execution','F','policy','initial','approval','numerical')
        ensure_lease_table(self.store.db)
        self.gen = acquire(self.store.db,self.ctx,2026,'worker')
    def tearDown(self):
        self.store.close(); os.unlink(self.path)
    def assert_rejected(self, fence):
        with self.assertRaises(ContractError):
            execute_year(self.store,self.ctx,2026,fence=fence,attempt_id='attempt')
        self.assertFalse(self.store.db.in_transaction)
        for table in ('gates','attempts','annual','year_end'):
            self.assertEqual(self.store.db.execute('SELECT count(*) FROM '+table).fetchone()[0],0)
    def test_none_fence(self): self.assert_rejected(None)
    def test_blank_owner(self): self.assert_rejected((' ',self.gen))
    def test_boolean_generation(self): self.assert_rejected(('worker',True))
    def test_zero_generation(self): self.assert_rejected(('worker',0))
    def test_list_fence(self): self.assert_rejected(['worker',self.gen])
    def test_oversized_tuple(self): self.assert_rejected(('worker',self.gen,'extra'))
