"""05BD local DRAFT: strict entry lease failure-path regression."""
import os
import tempfile
import unittest
from engine.m19_slice_a import RunContext, SliceAStore
from engine.m19_execution_api import execute_year
from engine.m19_worker_lease import ensure_lease_table, acquire, release

class StrictLeaseAbnormalTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix='.sqlite3'); os.close(fd)
        self.store = SliceAStore(self.path)
        self.ctx = RunContext('execution','F','policy','initial','approval','numerical')
        ensure_lease_table(self.store.db)

    def tearDown(self):
        self.store.close(); os.unlink(self.path)

    def counts(self):
        return tuple(self.store.db.execute('SELECT count(*) FROM '+n).fetchone()[0] for n in ('gates','attempts','annual','year_end'))

    def test_expired_lease_rejects_before_mutation(self):
        generation = acquire(self.store.db, self.ctx, 2026, 'worker', now=1, ttl=1)
        with self.assertRaises(Exception):
            execute_year(self.store,self.ctx,2026,fence=('worker',generation),attempt_id='attempt')
        self.assertEqual(self.counts(),(0,0,0,0))

    def test_released_lease_rejects_before_mutation(self):
        generation = acquire(self.store.db,self.ctx,2026,'worker')
        release(self.store.db,self.ctx,2026,'worker',generation)
        with self.assertRaises(Exception):
            execute_year(self.store,self.ctx,2026,fence=('worker',generation),attempt_id='attempt')
        self.assertEqual(self.counts(),(0,0,0,0))

    def test_exception_does_not_leave_open_transaction(self):
        generation = acquire(self.store.db,self.ctx,2026,'worker')
        with self.assertRaises(Exception):
            execute_year(self.store,self.ctx,2026,fence=('worker',generation+1),attempt_id='attempt')
        self.assertFalse(self.store.db.in_transaction)
        self.assertEqual(self.counts(),(0,0,0,0))

if __name__ == '__main__': unittest.main()
