"""05BQ local DRAFT: lease and strict fence adversarial boundaries."""
import math
import unittest
from engine.m19_slice_a import ContractError, ConflictError
from engine.m19_worker_lease import acquire, release
from tests import test_strict_runtime_adversarial as fixture

class LeaseBoundaryTests(fixture.StrictRuntimeAdversarialTests):
    def test_old_owner_cannot_release_after_takeover(self):
        g=acquire(self.a.db,self.ctx,2026,'old')
        self.a.db.execute('UPDATE worker_leases SET expires_at=0 WHERE year=2026'); self.a.db.commit()
        new_g=acquire(self.b.db,self.ctx,2026,'new')
        with self.assertRaises(ConflictError): release(self.a.db,self.ctx,2026,'old',g)
        self.assertEqual(new_g,g+1)
        self.assertFalse(self.a.db.in_transaction)
        self.assertTrue(self._run(self.b,2026,('new',new_g))[2])
    def test_invalid_ttl_rejected_without_lease_mutation(self):
        for ttl in (0,-1,3601,True,'30'):
            with self.subTest(ttl=ttl):
                with self.assertRaises(ContractError): acquire(self.a.db,self.ctx,2026,'old',ttl=ttl)
                self.assertEqual(self.a.db.execute('SELECT count(*) FROM worker_leases').fetchone()[0],0)
                self.assertFalse(self.a.db.in_transaction)
    def test_stale_generation_cannot_finalize(self):
        g=acquire(self.a.db,self.ctx,2026,'same')
        self.a.db.execute('UPDATE worker_leases SET expires_at=0 WHERE year=2026');self.a.db.commit()
        new_g=acquire(self.b.db,self.ctx,2026,'same')
        with self.assertRaises(ConflictError): self._run(self.a,2026,('same',g))
        self.assertEqual(new_g,g+1)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM annual').fetchone()[0],0)

for _name in list(vars(fixture.StrictRuntimeAdversarialTests)):
    if _name.startswith('test_'):
        setattr(LeaseBoundaryTests,_name,None)
