"""05BI local DRAFT: strict runtime lease/fence adversarial checks."""
import tempfile
import unittest
from pathlib import Path
from engine.m19_slice_a import RunContext, SliceAStore, ConflictError, digest
from engine.m19_strict_entry import run_year_strict
from engine.m19_worker_lease import ensure_lease_table, acquire, release
from engine.m19_m10_adapter import advance_one_year
from tests.test_gate_preflight import STATE, INITIAL, NUM, INPUT

class StrictRuntimeAdversarialTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        path=str(Path(self.tmp.name)/'run.db')
        self.a=SliceAStore(path); self.b=SliceAStore(path)
        self.ctx=RunContext('exec-fixture','path-fixture','policy-fixture','fixture-ic','fixture-only-not-real','fixture-nc')
        self.ic={**INITIAL,'state_digest':digest(STATE)}
        self.nc={**NUM,'policy_ref':'policy-fixture','covered_years':[2026,2027],
                 'initial_state_digest':digest(STATE),'annual_input_digests':{'2027':digest(INPUT)}}
        ensure_lease_table(self.a.db)
    def tearDown(self):
        self.a.close(); self.b.close(); self.tmp.cleanup()
    def _run(self, store, year, fence, **kw):
        args={'initial_contract':self.ic,'numerical_contract':self.nc,
              'attempt_id':f'attempt-{year}','fence':fence}
        if year==2026: args['initial_state']=STATE
        else: args.update(annual_inputs=INPUT,calculator=advance_one_year)
        args.update(kw)
        return run_year_strict(store,self.ctx,year,**args)
    def _prepare(self):
        gen=acquire(self.a.db,self.ctx,2026,'A')
        self.assertTrue(self._run(self.a,2026,('A',gen))[2])
        release(self.a.db,self.ctx,2026,'A',gen)
    def test_competing_owner_rejected_without_mutation(self):
        gen=acquire(self.a.db,self.ctx,2026,'A')
        with self.assertRaises(ConflictError): acquire(self.b.db,self.ctx,2026,'B')
        with self.assertRaises(ConflictError): self._run(self.b,2026,('B',gen))
        self.assertIsNone(self.a.read(self.ctx,2026))
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM gates').fetchone()[0],0)
    def test_expiry_before_execution_rejected_without_mutation(self):
        acquire(self.a.db,self.ctx,2026,'A',ttl=1,now=100)
        with self.assertRaises(ConflictError): self._run(self.a,2026,('A',1))
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM gates').fetchone()[0],0)
    def test_takeover_during_calculation_blocks_old_finalization(self):
        self._prepare()
        gen=acquire(self.a.db,self.ctx,2027,'A')
        def takeover(state, inputs):
            # Expiry is simulated in a second connection while the calculator runs.
            self.b.db.execute('UPDATE worker_leases SET expires_at=0 WHERE year=2027')
            self.b.db.commit()
            self.assertEqual(acquire(self.b.db,self.ctx,2027,'B'),gen+1)
            return advance_one_year(state,inputs)
        with self.assertRaises(ConflictError):
            self._run(self.a,2027,('A',gen),calculator=takeover)
        self.assertIsNone(self.a.read(self.ctx,2027))
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM year_end WHERE year=2027').fetchone()[0],0)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM attempts WHERE attempt_id=?',('attempt-2027',)).fetchone()[0],0)
    def test_calculator_exception_then_new_attempt_recovery(self):
        self._prepare()
        gen=acquire(self.a.db,self.ctx,2027,'A')
        def broken(state, inputs): raise RuntimeError('injected calculator failure')
        with self.assertRaisesRegex(RuntimeError,'injected calculator failure'):
            self._run(self.a,2027,('A',gen),calculator=broken)
        self.assertIsNone(self.a.read(self.ctx,2027))
        self.assertEqual(self.a.db.execute('SELECT status FROM attempts WHERE attempt_id=?',('attempt-2027',)).fetchone()[0],'FAILED')
        result=self._run(self.a,2027,('A',gen),attempt_id='retry-2027')
        self.assertTrue(result[2]); self.assertEqual(self.a.read(self.ctx,2027)[0]['year'],2027)
