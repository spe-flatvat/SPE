import tempfile
import unittest
from pathlib import Path
from engine.m19_slice_a import SliceAStore,RunContext,ConflictError
from engine.m19_worker_lease import ensure_lease_table,acquire,assert_fence_in_transaction,release

CTX=RunContext('e','p','F','init','approval','inputs')

class WorkerLeaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.tmp.name)/'a.sqlite')
        self.a=SliceAStore(self.path)
        self.b=SliceAStore(self.path)
        ensure_lease_table(self.a.db)
    def tearDown(self):
        self.a.close();self.b.close();self.tmp.cleanup()
    def test_second_worker_rejected(self):
        acquire(self.a.db,CTX,2026,'A',now=100)
        with self.assertRaises(ConflictError): acquire(self.b.db,CTX,2026,'B',now=110)
    def test_expired_takeover_increments_generation(self):
        self.assertEqual(acquire(self.a.db,CTX,2026,'A',ttl=10,now=100),1)
        self.assertEqual(acquire(self.b.db,CTX,2026,'B',ttl=10,now=110),2)
    def test_stale_fence_rejected_at_finalization(self):
        acquire(self.a.db,CTX,2026,'A',ttl=10,now=100)
        acquire(self.b.db,CTX,2026,'B',ttl=100000 if False else 100,now=110)
        self.a.attempt(CTX,2026,'old','PENDING',None,None)
        with self.assertRaises(ConflictError):
            self.a.finalize(CTX,2026,{'year':2026},'old',None,fence=('A',1))
        self.assertIsNone(self.a.read(CTX,2026))
    def test_current_fence_can_finalize(self):
        generation=acquire(self.a.db,CTX,2026,'A',ttl=100,now=__import__('time').time())
        self.a.attempt(CTX,2026,'a','PENDING',None,None)
        self.assertTrue(self.a.finalize(CTX,2026,{'year':2026},'a',None,fence=('A',generation))[2])
    def test_release_then_reacquire(self):
        gen=acquire(self.a.db,CTX,2026,'A')
        release(self.a.db,CTX,2026,'A',gen)
        self.assertEqual(acquire(self.b.db,CTX,2026,'B'),2)

    def test_released_owner_cannot_reuse_generation(self):
        gen=acquire(self.a.db,CTX,2026,'A')
        release(self.a.db,CTX,2026,'A',gen)
        next_gen=acquire(self.b.db,CTX,2026,'A')
        self.assertEqual(next_gen,gen+1)
        self.a.attempt(CTX,2026,'old','PENDING',None,None)
        with self.assertRaises(ConflictError):
            self.a.finalize(CTX,2026,{'year':2026},'old',None,fence=('A',gen))
