import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'engine'))
from m19_slice_a import SliceAStore, RunContext, run_year, ConflictError, ContractError

CTX = RunContext('exec','F','policy','initial','approval','annual')
INIT = {'year':2026,'real_gdp':580.0,'nominal_gdp':600.0}

class TestYearEndIntegrity(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name)/'s.db')
        self.store = SliceAStore(self.path)
    def tearDown(self):
        self.store.close(); self.temp.cleanup()
    def init(self):
        return run_year(self.store, CTX, 2026, initial_state=INIT, annual_inputs=None, calculator=None, attempt_id='init')
    def test_missing_year_end_blocks_carry(self):
        self.init()
        self.store.db.execute('DELETE FROM year_end WHERE year=2026'); self.store.db.commit()
        with self.assertRaisesRegex(ConflictError, 'year-end'):
            run_year(self.store,CTX,2027,initial_state=None,annual_inputs={'delta':1},calculator=lambda s,i:{'year':2027},attempt_id='next')
    def test_mismatched_year_end_digest_blocks_read(self):
        self.init()
        self.store.db.execute("UPDATE year_end SET result_digest='wrong' WHERE year=2026"); self.store.db.commit()
        with self.assertRaises(ConflictError): self.store.read(CTX,2026)
    def test_invalid_attempt_id_fails_closed(self):
        with self.assertRaises(ContractError):
            run_year(self.store,CTX,2026,initial_state=INIT,annual_inputs=None,calculator=None,attempt_id=None)
    def test_unexpected_initial_year_inputs_fail(self):
        with self.assertRaises(ContractError):
            run_year(self.store,CTX,2026,initial_state=INIT,annual_inputs={'delta':1},calculator=None,attempt_id='init')
        self.assertIsNone(self.store.read(CTX,2026))
    def test_concurrent_commit_unique(self):
        self.init()
        self.store.attempt(CTX,2027,'a','PENDING',None,None)
        self.store.attempt(CTX,2027,'b','PENDING',None,None)
        state={'year':2027,'real_gdp':581.0,'nominal_gdp':601.0}
        prev=self.store.read(CTX,2026)[1]
        self.store.finalize(CTX,2027,state,'a',prev)
        state2={'year':2027,'real_gdp':582.0,'nominal_gdp':602.0}
        with self.assertRaises(ConflictError): self.store.finalize(CTX,2027,state2,'b',prev)
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM year_end WHERE year=2027').fetchone()[0],1)
        self.assertEqual(self.store.db.execute('SELECT status FROM attempts WHERE attempt_id=?',('b',)).fetchone()[0],'PENDING')

if __name__=='__main__': unittest.main()
